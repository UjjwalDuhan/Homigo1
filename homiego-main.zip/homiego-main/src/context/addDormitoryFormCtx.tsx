import React, { createContext, useContext } from "react";

// Create a context
export const FormSubmitContext = createContext(null);

export const useFormSubmit = () => useContext(FormSubmitContext);

import { NextRequest, NextResponse } from "next/server";
import { auth } from "./auth";

const Middleware = auth((req, res) => {
  console.log("Auth Middleware");

  console.log(req.auth);
  if (req.nextUrl.pathname.startsWith("/my-profile") && !req.auth) {
    return NextResponse.redirect(new URL("/auth/login", req.url));
  }
  if (req.nextUrl.pathname.startsWith("/auth") && req.auth) {
    return NextResponse.redirect(new URL("/", req.url));
  }
  if (
    req.nextUrl.pathname.startsWith("/admin") &&
    req.auth?.user.role !== "ADMIN"
  ) {
    return NextResponse.redirect(new URL("/", req.url));
  }
});

export const config = {
  // The following matcher runs middleware on all routes
  // except static assets.
  matcher: ["/((?!.*\\..*|_next).*)", "/", "/(api|trpc)(.*)"],
};
export default Middleware;

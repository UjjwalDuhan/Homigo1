"use client";

import React from "react";
import ScrollToTop from "react-scroll-to-top";
import { usePathname } from "next/navigation";

export default function MobWrapper({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  const path = usePathname();
  return (
    <>
      {path.startsWith("/admin") ? (
        <>{children}</>
      ) : (
        <div className="w-full flex justify-center items-center bg-muted min-h-screen">
          <div className="max-w-screen-sm w-full bg-card shadow-sm min-h-screen flex flex-col">
            {children}
            <ScrollToTop
              style={{ zIndex: 50, bottom: "6rem", right: "2rem" }}
              className="flex z-50 items-center justify-center"
              smooth
            />
          </div>
        </div>
      )}
    </>
  );
}

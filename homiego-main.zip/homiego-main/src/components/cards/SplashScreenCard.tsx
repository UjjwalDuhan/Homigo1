import React from "react";

interface SplashScreenCardProps {
  title: string;
  desc: string;
}

export default function SplashScreenCard(props: SplashScreenCardProps) {
  return (
    <div className="h-full">
      <div className="mt-6"></div>
      <h2 className="text-center text-balance text-2xl font-bold text-primary mb-1.5">
        {props.title}
      </h2>
      <p className="text-center text-pretty font-medium text-neutral-700">
        Lorem ipsum dolor sit, amet consectetur adipisicing elit. Explicabo
        aliquid amet fuga possimus iste eius. Libero, rerum dolor!
      </p>
    </div>
  );
}

/* eslint-disable react/no-unescaped-entities */
"use client";

import React from "react";
import MaxWidthWrapper from "../wrappers/MaxWidthWrapper";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Sheet,
  SheetClose,
  SheetContent,
  SheetDescription,
  SheetFooter,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";
import { usePathname } from "next/navigation";
import Link from "next/link";
import { LuBell, LuLayoutDashboard } from "react-icons/lu";
import { IoChevronBack } from "react-icons/io5";
import { useRouter } from "next/navigation";

export default function Header() {
  const path = usePathname();
  const router = useRouter();
  const pathSplit = path.split("/");
  return (
    <div className="py-5 px-1">
      <MaxWidthWrapper>
        <div className="flex justify-between items-center relative">
          {path === "/" ? (
            <>
              <Sheet>
                <SheetTrigger asChild>
                  <Button
                    variant={"ghost"}
                    size={"icon"}
                    className="rounded-full size-10"
                  >
                    <LuLayoutDashboard className="text-2xl" />
                  </Button>
                </SheetTrigger>
                <SheetContent side={"left"}>
                  <SheetHeader>
                    <SheetTitle>Edit profile</SheetTitle>
                    <SheetDescription>
                      Make changes to your profile here. Click save when you're
                      done.
                    </SheetDescription>
                  </SheetHeader>
                  <div className="grid gap-4 py-4">
                    <div className="grid grid-cols-4 items-center gap-4">
                      <Label htmlFor="name" className="text-right">
                        Name
                      </Label>
                      <Input
                        id="name"
                        value="Pedro Duarte"
                        className="col-span-3"
                      />
                    </div>
                    <div className="grid grid-cols-4 items-center gap-4">
                      <Label htmlFor="username" className="text-right">
                        Username
                      </Label>
                      <Input
                        id="username"
                        value="@peduarte"
                        className="col-span-3"
                      />
                    </div>
                  </div>
                  <SheetFooter>
                    <SheetClose asChild>
                      <Button type="submit">Save changes</Button>
                    </SheetClose>
                  </SheetFooter>
                </SheetContent>
              </Sheet>
              <Link
                href="/"
                className="absolute left-1/2 transform -translate-x-1/2"
              >
                <h1 className="text-2xl font-semibold">
                  Homie<span className="text-rose-500">Go</span>
                </h1>
              </Link>
              <Sheet>
                <SheetTrigger asChild>
                  <Button
                    variant={"ghost"}
                    size={"icon"}
                    className="rounded-full size-10"
                  >
                    <LuBell className="text-2xl" />
                  </Button>
                </SheetTrigger>
                <SheetContent>
                  <SheetHeader>
                    <SheetTitle>Edit profile</SheetTitle>
                    <SheetDescription>
                      Make changes to your profile here. Click save when you're
                      done.
                    </SheetDescription>
                  </SheetHeader>
                  <div className="grid gap-4 py-4">
                    <div className="grid grid-cols-4 items-center gap-4">
                      <Label htmlFor="name" className="text-right">
                        Name
                      </Label>
                      <Input
                        id="name"
                        value="Pedro Duarte"
                        className="col-span-3"
                      />
                    </div>
                    <div className="grid grid-cols-4 items-center gap-4">
                      <Label htmlFor="username" className="text-right">
                        Username
                      </Label>
                      <Input
                        id="username"
                        value="@peduarte"
                        className="col-span-3"
                      />
                    </div>
                  </div>
                  <SheetFooter>
                    <SheetClose asChild>
                      <Button type="submit">Save changes</Button>
                    </SheetClose>
                  </SheetFooter>
                </SheetContent>
              </Sheet>
            </>
          ) : (
            <>
              <Button
                variant={"outline"}
                size={"icon"}
                onClick={() => router.back()}
                className="rounded-full size-10"
              >
                <IoChevronBack className="text-2xl" />
              </Button>
              <div className="absolute left-1/2 transform -translate-x-1/2">
                <h1 className="text-2xl font-semibold capitalize">
                  {path.startsWith("/dormitory")
                    ? pathSplit[1]
                    : path.split("/")[pathSplit.length - 1]}
                </h1>
              </div>
            </>
          )}
        </div>
      </MaxWidthWrapper>
    </div>
  );
}

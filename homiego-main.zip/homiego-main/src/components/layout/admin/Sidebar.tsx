"use client";

import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import Link from "next/link";
import { usePathname } from "next/navigation";
import React from "react";
import {
  FaAccessibleIcon,
  FaChevronLeft,
  FaHome,
  FaUserTie,
} from "react-icons/fa";
import { IoLogoWebComponent, IoStatsChart } from "react-icons/io5";
import { BiSolidDashboard } from "react-icons/bi";
import { FaCartShopping, FaTags } from "react-icons/fa6";
import { IoPerson } from "react-icons/io5";
import { TbPinned } from "react-icons/tb";
import { BiSolidOffer } from "react-icons/bi";
import axios from "axios";

const sidebarItems = [
  {
    name: "Overview",
    icon: BiSolidDashboard,
    href: "/admin/index",
  },
  {
    name: "Dormitories",
    icon: FaUserTie,
    href: "/admin/dormitories",
  },
  {
    name: "Bookings",
    icon: FaCartShopping,
    href: "/admin/bookings",
  },
  {
    name: "Customers",
    icon: IoPerson,
    href: "/admin/customers",
  },
  {
    name: "Analytics",
    icon: IoStatsChart,
    href: "/admin/analytics",
  },
  {
    name: "Marketing",
    icon: TbPinned,
    href: "/admin/marketing",
  },
  {
    name: "Discounts",
    icon: BiSolidOffer,
    href: "/admin/discounts",
  },
];

export default function Sidebar({
  isSidebarOpen,
  setIsSidebarOpen,
}: {
  isSidebarOpen: boolean;
  setIsSidebarOpen: (isSidebarOpen: boolean) => void;
}) {
  const path = usePathname();
  const [newSellers, setNewSellers] = React.useState(0);
  const getSellersNumber = async () => {
    // const { data } = await axios.get("/api/admin/sidebar");
    // setNewSellers(data?.newSellers.length);
  };

  React.useEffect(() => {
    getSellersNumber();
  }, []);
  return (
    <div
      className={cn(
        "h-dvh w-[22rem] px-8 bg-neutral-50 sticky top-0 transition-all hidden lg:flex flex-col",
        {
          "transform -translate-x-full -z-10": !isSidebarOpen,
        }
      )}
    >
      <div className="flex gap-3 items-center h-20 relative">
        <IoLogoWebComponent className="text-3xl" />
        <h1 className="text-2xl font-semibold text-primary">
          <span className="text-black">Homie</span>Go
        </h1>
      </div>
      <div className="my-2 mb-6">
        <p className="text-muted-foreground text-sm">Main Menu</p>
        {sidebarItems.map((item, index) => {
          const Icon = item.icon;
          return (
            <Link
              href={index === 0 ? "/admin" : item.href}
              key={index}
              className=""
            >
              <div
                className={cn(
                  "flex items-center justify-between transition-all text-muted-foreground hover:text-black hover:bg-muted px-4 py-3 cursor-pointer select-none rounded-xl my-1",
                  {
                    "bg-muted text-black":
                      index === 0
                        ? path === "/admin"
                        : path.startsWith(item.href),
                  }
                )}
              >
                <div className="flex items-center gap-3">
                  <Icon />
                  <p className="font-medium">{item.name}</p>
                </div>
                {index === 1 && newSellers !== 0 && <Badge>{newSellers}</Badge>}
                {index === 2 && <Badge>2</Badge>}
              </div>
            </Link>
          );
        })}
      </div>
      <div className="my-2">
        <p className="text-muted-foreground text-sm">Sales Channel</p>
        <Link href={"/"} className="">
          <div
            className={cn(
              "flex items-center justify-between transition-all text-muted-foreground hover:text-black hover:bg-muted px-4 py-3 cursor-pointer select-none rounded-xl my-1"
            )}
          >
            <div className="flex items-center gap-3">
              <FaHome />
              <p className="font-medium">Online Store</p>
            </div>
          </div>
        </Link>
      </div>
    </div>
  );
}

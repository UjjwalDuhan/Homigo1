"use client";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { usePathname, useRouter, useSearchParams } from "next/navigation";
import { set } from "nprogress";
import React, { useCallback, useEffect, useRef } from "react";
import { FaSearch } from "react-icons/fa";
import { IoIosSearch } from "react-icons/io";
import { useDebouncedCallback } from "use-debounce";

export default function Search() {
  const router = useRouter();
  const pathname = usePathname();
  const searchParams = useSearchParams();
  const [query, setQuery] = React.useState(searchParams.get("q") || "");

  // Get a new searchParams string by merging the current
  // searchParams with a provided key/value pair
  const createQueryString = useCallback(
    (name: string, value: string) => {
      const params = new URLSearchParams(searchParams.toString());
      params.set(name, value);

      return params.toString();
    },
    [searchParams]
  );
  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    router.replace(`${pathname}?${createQueryString("q", query)}`);
  };

  const handleInstantSearch = useDebouncedCallback((value: string) => {
    // setQuery(value);
    router.replace(`${pathname}?${createQueryString("q", value)}`);
  }, 300);

  const inputRef: any = useRef(null);

  useEffect(() => {
    const handleKeyPress = (event: any) => {
      // Check if the "/" key is pressed (key code 191)
      if (event.keyCode === 191) {
        event.preventDefault();
        // Focus the input field when the "/" key is pressed
        inputRef.current.focus();
      }
    };

    // Add event listener for keydown events
    document.addEventListener("keydown", handleKeyPress);

    // Cleanup function to remove event listener
    return () => {
      document.removeEventListener("keydown", handleKeyPress);
    };
  }, []); // Empty dependency array ensures that the effect runs only once

  // useEffect(() => {
  //   setQuery(searchParams.get("q") || "");
  // }, []);

  return (
    <form onSubmit={handleSearch} className="w-full max-w-[26rem]">
      <div className="flex gap-2 items-center h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-within:outline-none focus-within:ring-2 focus-within:ring-ring focus-within:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50">
        <IoIosSearch className="text-xl min-w-max" />
        <input
          className="focus:outline-none w-full"
          defaultValue={query}
          onChange={(e) => {
            setQuery(e.target.value);
            handleInstantSearch(e.target.value);
          }}
          type="text"
          placeholder="Search..."
          ref={inputRef}
        />
        {searchParams.get("q") ? (
          <Button
            type="button"
            onClick={() => {
              setQuery("");
              inputRef.current.value = "";
              router.replace(`${pathname}?${createQueryString("q", "")}`);
            }}
            size={"sm"}
            className="h-6 w-12"
          >
            Clear
          </Button>
        ) : (
          query.length === 0 && (
            <p className="text-xs font-medium text-muted-foreground flex items-center gap-2">
              press <span className="bg-muted p-1 px-2 rounded">/</span>
            </p>
          )
        )}
      </div>
    </form>
  );
}

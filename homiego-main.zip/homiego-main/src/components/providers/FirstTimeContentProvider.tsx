import React from "react";
import { Button } from "../ui/button";
import MaxWidthWrapper from "../wrappers/MaxWidthWrapper";
import { cn } from "@/lib/utils";
import { useRouter } from "next/navigation";
import SplashScreenCard from "../cards/SplashScreenCard";
import Image from "next/image";

export default function FirstTimeContentProvider({
  setVisited,
}: {
  setVisited: (visited: boolean) => void;
}) {
  const [step, setStep] = React.useState(1);
  const router = useRouter();
  return (
    <div className="w-full h-[100dvh] py-6">
      <MaxWidthWrapper className="flex flex-col h-full">
        <div className="flex justify-end items-center">
          <Button
            variant={"ghost"}
            className="underline text-base text-pretty text-primary"
            onClick={() => {
              localStorage.setItem("visited", "true");
              setVisited(true);
              router.push("/");
            }}
          >
            Skip
          </Button>
        </div>
        <div className="flex-grow ">
          {step === 1 ? (
            <div>
              <div className="aspect-square p-12 relative w-full">
                <Image
                  src={"/logo.png"}
                  alt="logo"
                  fill
                  className="object-contain p-12"
                />
              </div>
              <h1 className="text-center">
                <span className="text-pretty text-4xl font-bold text-primary">
                  Welcome to HomieGo
                </span>
              </h1>
              <p className="text-center">
                <span className="text-center text-pretty font-medium text-neutral-700">
                  For the students, by the students.
                </span>
              </p>
            </div>
          ) : step === 2 ? (
            <SplashScreenCard
              title="Fast Delivery"
              desc="lorem sad asd as d asd as das das d asd asd as dw dwajdhwjkad kaj djwhdjka dkjawh "
            />
          ) : (
            <SplashScreenCard
              title="Enjoy your Food"
              desc="lorem sad asd as d asd as das das d asd asd as dw dwajdhwjkad kaj djwhdjka dkjawh "
            />
          )}
        </div>
        <div className="flex items-center justify-center gap-3">
          <div
            className={cn(
              "rounded-full border border-primary w-4 h-4 transition-all duration-700",
              {
                "bg-primary": step === 1,
              }
            )}
            onClick={() => setStep(1)}
          />
          <div
            className={cn(
              "rounded-full border border-primary w-4 h-4 transition-all duration-700",
              {
                "bg-primary": step === 2,
              }
            )}
            onClick={() => setStep(2)}
          />
          <div
            className={cn(
              "rounded-full border border-primary w-4 h-4 transition-all duration-700",
              {
                "bg-primary": step === 3,
              }
            )}
            onClick={() => setStep(3)}
          />
        </div>
        <div
          className={cn("flex items-center justify-between my-5", {
            "justify-end": step === 1,
          })}
        >
          <Button
            size={"lg"}
            variant={"ghost"}
            className={cn("text-lg text-pretty text-primary", {
              hidden: step === 1,
            })}
            onClick={() => setStep(step - 1)}
          >
            Back
          </Button>
          <Button
            size={"lg"}
            variant={"ghost"}
            className={cn("text-lg text-pretty text-primary", {
              hidden: step === 3,
            })}
            onClick={() => setStep(step + 1)}
            disabled={step === 3}
          >
            Next
          </Button>
          {step === 3 && (
            <Button
              className="rounded-md"
              size={"lg"}
              onClick={() => {
                localStorage.setItem("visited", "true");
                setVisited(true);
                router.push("/");
              }}
            >
              Get Started
            </Button>
          )}
        </div>
      </MaxWidthWrapper>
    </div>
  );
}

"use client";

import React, { useEffect, useState } from "react";
import { usePathname } from "next/navigation";
import Nav from "../layout/Nav";
import ScrollToTop from "react-scroll-to-top";
import Header from "../layout/Header";
import FirstTimeContentProvider from "./FirstTimeContentProvider";
import AdminLayoutProvider from "./AdminLayoutProvider";
import * as LR from "@uploadcare/blocks";
import "@uploadcare/blocks/web/lr-file-uploader-regular.min.css";
LR.registerBlocks(LR);

export default function LayoutProvider({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  const path = usePathname();
  const [onboardingComplete, setOnboardingComplete] = useState(true);
  const [visited, setVisited] = React.useState(true);
  useEffect(() => {
    setVisited(localStorage.getItem("visited") === "true" ? true : false);
  }, []);

  if (!visited) {
    return <FirstTimeContentProvider setVisited={setVisited} />;
  }
  if (path.startsWith("/auth")) return <>{children}</>;
  if (path.startsWith("/admin"))
    return <AdminLayoutProvider>{children}</AdminLayoutProvider>;
  return (
    <>
      <Header />
      <div className="flex flex-col min-h-[calc(100dvh-11rem)] mb-[6rem]">
        {children}
      </div>
      <div className="w-full h-20 bg-gradient-to-b from-transparent to-white fixed bottom-0 left-0 lg:hidden" />
      {path.startsWith("/dormitory") ? <> </> : <Nav />}
    </>
  );
}

"use client";

import React from "react";
import Sidebar from "../layout/admin/Sidebar";
import Header from "../layout/admin/Header";

export default function AdminLayoutProvider({
  children,
}: {
  children: React.ReactNode;
}) {
  const [isSidebarOpen, setIsSidebarOpen] = React.useState(true);
  return (
    <div className="w-full min-h-dvh flex">
      <Sidebar
        isSidebarOpen={isSidebarOpen}
        setIsSidebarOpen={setIsSidebarOpen}
      />
      <div className="min-h-dvh w-full">
        <Header />
        <div className="px-8 py-6">{children}</div>
      </div>
    </div>
  );
}

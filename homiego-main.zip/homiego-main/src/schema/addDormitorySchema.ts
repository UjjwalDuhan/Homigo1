import { z } from "zod";

const validateNonNegativeNumber = z
  .number({
    required_error: "Distance is required",
    invalid_type_error: "Distance must be a number",
  })
  .max(10, { message: "Distance must be less than 10km" })
  .refine((val) => !isNaN(val) && val >= 0, {
    message: "Distance must be a non-negative number.",
  });

export const addDormitorySchema = z.object({
  name: z.string().min(2, { message: "Name must be at least 2 characters." }),
  description: z
    .string()
    .min(2, { message: "Description must be at least 2 characters." }),
  address: z
    .string()
    .min(2, { message: "Address must be at least 2 characters." }),
  distanceFromHospital: validateNonNegativeNumber,
  distanceFromMarket: validateNonNegativeNumber,
  bookingPrice: z.number().positive("Booking price must be a positive number"),
  ifscCode: z
    .string()
    .length(11, { message: "IFSC code must be 11 characters" }),
  accountNumber: z
    .string()
    .length(16, { message: "Account number must be 16 characters" }),
  beneficiaryName: z.string().min(2, {
    message: "Beneficiary Name name must be at least 2 characters.",
  }),
  addharCard: z
    .string()
    .length(12, { message: "Addhar card must be 12 characters" })
    .optional(),
  panCard: z.string().length(10, { message: "Pan card must be 10 characters" }),
});

export type addDormitorySchema = z.infer<typeof addDormitorySchema>;

import { z } from "zod";

export const onboardingFormSchema = z.object({
  pan: z.string().regex(/^[A-Z]{5}[0-9]{4}[A-Z]{1}$/, {
    message: "Invalid PAN format. Example: ABCDE1234F",
  }),
  gstin: z
    .string()
    .regex(/^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[0-9]{1}[Z]{1}[0-9A-Z]{1}$/, {
      message: "Invalid GSTIN format. Example: 12ABCDE1234F1Z5",
    }),
});
export type onboardingFormSchema = z.infer<typeof onboardingFormSchema>;

"use server";

import { prisma } from "@/lib/prisma/prisma";
import SessionChecker from "@/lib/session/SessionChecker";
import {
  deleteFiles,
  UploadcareSimpleAuthSchema,
} from "@uploadcare/rest-client";
import { revalidatePath } from "next/cache";
const uploadcareSimpleAuthSchema = new UploadcareSimpleAuthSchema({
  publicKey: "7927fe6ba0130bf1d295",
  secretKey: "dc6c1f2dc41755591853",
});

export const createDormitoryAction = async (data: any) => {
  SessionChecker({
    role: "ADMIN",
  });

  try {
    const dormitory = await prisma.dormitory.create({
      data: {
        name: data.name,
        address: data.address,
        description: data.description,
        facilities: data.facilities,
        bookingPrice: data.bookingPrice,
        category: data.category,
        distanceFromHospital: Number(data.distanceFromHospital),
        distanceFromMarket: Number(data.distanceFromMarket),
        images: data.images,
        status: data.status ?? "ACTIVE",
        variants: {
          create: data.variants,
        },
        nearByColleges: {
          create: data.colleges.map((college: any) => ({
            collegeId: college.collegeId,
            distance: college.distance,
          })),
        },
        owner: {
          connect: {
            email: data.owner,
          },
        },
        pincode: "201301",
        price: data.price,
        managers: {
          connect: data.managers.map((manager: any) => ({
            email: manager,
          })),
        },
        imageContext: data.imageContext,
        bankDetails: {
          create: {
            ifscCode: data.ifscCode,
            accountNumber: data.accountNumber,
            beneficiaryName: data.beneficiaryName,
            user: {
              connect: {
                email: data.owner,
              },
            },
          },
        },
      },
    });
    await prisma.user.update({
      where: {
        email: data.owner,
      },
      data: {
        role: "OWNER",
        addharCard: data.addharCard,
        panCard: data.panCard,
      },
    });
    await prisma.user.updateMany({
      where: {
        email: {
          in: data.managers,
        },
      },
      data: {
        role: "MANAGER",
      },
    });
    return {
      status: 200,
      data: {
        message: "Dormitory created successfully",
      },
    };
  } catch (error: any) {
    throw new Error(error);
  }
};

function extractUUID(url: string) {
  const startIndex = url.lastIndexOf("/") + 1;
  return url.substring(startIndex);
}

export const deleteDormitoryAction = async (id: string) => {
  SessionChecker({
    role: "ADMIN",
  });

  try {
    const dormitory = await prisma.dormitory.findFirst({
      where: {
        id,
      },
    });

    await prisma.dormitoryCollege.deleteMany({
      where: {
        dormitoryId: id,
      },
    });

    const uuids = dormitory?.images.map((url) => extractUUID(url)) as string[];
    await deleteFiles(
      {
        uuids,
      },
      {
        authSchema: uploadcareSimpleAuthSchema,
      }
    );
    await prisma.dormitory.delete({
      where: {
        id,
      },
    });
    revalidatePath("/admin/dormitories");
    revalidatePath("/");

    return {
      status: 200,
      data: {
        message: "Dormitory deleted successfully",
      },
    };
  } catch (error: any) {
    throw new Error(error);
  }
};

export const updateDormitoryAction = async (id: string, data: any) => {
  console.log("data", data); // Fixed console.log statement
  try {
    await prisma.dormitory.update({
      where: {
        id,
      },
      data: {
        name: data.name,
        address: data.address,
        description: data.description,
        facilities: data.facilities,
        bookingPrice: data.bookingPrice,
        category: data.category,
        distanceFromHospital: Number(data.distanceFromHospital),
        distanceFromMarket: Number(data.distanceFromMarket),
        images: data.images,
        status: data.status ?? "ACTIVE",
        variants: {
          deleteMany: {}, // Fixed empty object
          createMany: {
            data: data.variants.map((variant: any) => variant), // Removed unnecessary object wrapping
          },
        },
        nearByColleges: {
          deleteMany: {}, // Add deleteMany property for nearByColleges
          create: data.colleges.map((college: any) => ({
            collegeId: college.collegeId,
            distance: college.distance,
          })),
        },
        owner: {
          connect: {
            email: data.owner,
          },
        },
        pincode: "201301",
        price: data.price,
        managers: {
          connect: data.managers.map((manager: any) => ({
            email: manager.value,
          })),
        },
        imageContext: data.imageContext,
      },
    });
    return {
      status: 200,
      data: {
        message: "Dormitory updated successfully", // Corrected message
      },
    };
  } catch (error: any) {
    throw new Error(error.message); // Throwing error message instead of entire error object
  }
};

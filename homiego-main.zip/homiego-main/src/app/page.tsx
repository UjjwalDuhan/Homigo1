import SearchComponent from "@/components/reusable/SearchComponent";
import { Button } from "@/components/ui/button";
import MaxWidthWrapper from "@/components/wrappers/MaxWidthWrapper";
import Image from "next/image";
import ToggleComp from "./(components)/ToggleComp";
import FeaturedListings from "./(components)/FeaturedListings";
import CardListings from "./(components)/CardListings";

export default function Home({
  params,
  searchParams,
}: {
  params: { id: string };
  searchParams: { [key: string]: string | string[] | undefined };
}) {
  return (
    <main className="space-y-6">
      <MaxWidthWrapper>
        <div className="space-y-6">
          <SearchComponent />
          <ToggleComp />
        </div>
      </MaxWidthWrapper>
      <div className="space-y-6 pl-6">
        <FeaturedListings searchParams={searchParams} params={params} />
      </div>
      <CardListings
        title="Nearest Listings"
        feature="View All"
        searchParams={searchParams}
      />
    </main>
  );
}

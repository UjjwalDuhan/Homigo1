import type { Metadata, Viewport } from "next";
import { Inter } from "next/font/google";
import "./globals.css";
import { cn } from "@/lib/utils";
import { Suspense } from "react";
import TopLoader from "@/components/loaders/TopLoader";
import AuthSessionProvider from "@/components/providers/AuthSessionProvider";
import { ThemeProvider } from "@/components/providers/ThemeProvider";
import { Toaster } from "@/components/ui/sonner";
import LayoutProvider from "@/components/providers/LayoutProvider";
import MobWrapper from "@/components/wrappers/MobWrapper";
import SplashScreenProvider from "@/components/providers/SplashScreenProvider";

const inter = Inter({ subsets: ["latin"] });

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  themeColor: "#ffffff",
};

export const metadata: Metadata = {
  title: {
    default: "HomieGo",
    template: "%s | HomieGo",
  },
  keywords: [
    "HomieGo",
    "hostel booking",
    "PG accommodation",
    "temporary housing options",
    "student accommodation",
    "professional housing",
    "traveler accommodation",
    "affordable hostels",
    "convenient hostel booking",
    "verified reviews",
    "user-friendly platform",
    "comfortable living spaces",
    "hassle-free accommodation booking",
    "budget-friendly hostels",
    "comprehensive accommodation platform",
    "secure hostel reservations",
    "easy PG accommodation booking",
    "hostel comparison",
    "search filters",
    "homestay options",
    "discounted hostels",
    "trusted accommodation reviews",
    "homestay bookings",
    "hostel amenities",
    "HomieGo reviews",
    "best hostels",
    "top-rated PG accommodations",
    "student housing",
    "affordable temporary housing",
    "professional accommodation",
    "traveler-friendly hostels",
  ],
  description:
    "Welcome to HomieGo - Your Ultimate Destination for Hassle-Free Hostel and PG Accommodation Booking! Discover the easiest way to find, compare, and reserve the perfect living space tailored to your needs. Whether you're a student, a professional, or a traveler, HomieGo offers a user-friendly platform with detailed listings, verified reviews, and convenient search filters. Say goodbye to the stress of finding comfortable and affordable temporary housing options - with HomieGo, booking your ideal hostel or PG accommodation has never been easier!",
  metadataBase: new URL("https://homiego.in"),
  openGraph: {
    siteName: "HomieGo",
    type: "website",
    locale: "en_US",
    title: {
      default: "HomieGo",
      template: "%s | HomieGo",
    },
    description:
      "Welcome to HomieGo - Your Ultimate Destination for Hassle-Free Hostel and PG Accommodation Booking! Discover the easiest way to find, compare, and reserve the perfect living space tailored to your needs. Whether you're a student, a professional, or a traveler, HomieGo offers a user-friendly platform with detailed listings, verified reviews, and convenient search filters. Say goodbye to the stress of finding comfortable and affordable temporary housing options - with HomieGo, booking your ideal hostel or PG accommodation has never been easier!",
    images: [
      {
        url: "https://homiego.in/logo.png",
      },
    ],
    url: "https://homiego.in/",
  },
  robots: {
    index: true,
    follow: true,
    "max-image-preview": "large",
    "max-snippet": -1,
    "max-video-preview": -1,
    googleBot: "index, follow",
  },
  // alternates: {
  //   types: {
  //     "application/rss+xml": "https://homiego.in/rss.xml",
  //   },
  // },
  applicationName: "HomieGo",
  appleWebApp: {
    title: "HomieGo",
    statusBarStyle: "default",
    capable: true,
  },
  manifest: "/manifest.json",
  icons: { apple: "/logo.png" },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={cn("bg-background font-sans antialiased", inter.className)}
      >
        <Suspense>
          <AuthSessionProvider>
            <ThemeProvider
              attribute="class"
              disableTransitionOnChange
              forcedTheme="light"
            >
              <MobWrapper>
                <TopLoader />
                <Toaster richColors position="top-center" />
                <LayoutProvider>{children}</LayoutProvider>
                <SplashScreenProvider />
              </MobWrapper>
            </ThemeProvider>
          </AuthSessionProvider>
        </Suspense>
      </body>
    </html>
  );
}

import React from "react";
import { FaRegCalendarCheck, FaUsers } from "react-icons/fa";
import { IconType } from "react-icons/lib";
import { MdApartment, MdAttachMoney } from "react-icons/md";
import * as Icon from "react-icons/fc";

const DEHG = ({
  icon,
  label,
  number,
}: {
  label: string;
  icon: IconType;
  number: number;
}) => {
  const Icon = icon;
  return (
    <div className="flex items-center gap-3 px-5 py-3 bg-muted/40 w-full rounded-md">
      <div className="rounded-full bg-muted size-11 flex items-center justify-center">
        <Icon className="text-lg" />
        {/* <MdAttachMoney />
            <MdApartment />
            <FaUsers /> */}
      </div>
      <div>
        <p className="text-sm text-muted-foreground">{label}</p>
        <p className="text-xl font-medium">{number}</p>
      </div>
    </div>
  );
};

export default function page() {
  return (
    <div>
      <div className="grid grid-cols-4 gap-4">
        <DEHG icon={FaRegCalendarCheck} label="Total Bookings" number={100} />
        <DEHG icon={MdAttachMoney} label="Total Revenue" number={100} />
        <DEHG icon={MdApartment} label="Total Dormitories" number={100} />
        <DEHG icon={FaUsers} label="Total Users" number={100} />
      </div>
    </div>
  );
}

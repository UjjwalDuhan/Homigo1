"use client";

import React, { useEffect, useRef, useState } from "react";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { ToggleGroup, ToggleGroupItem } from "@/components/ui/toggle-group";
import { Button } from "@/components/ui/button";
import { PlusCircle, Trash, Upload } from "lucide-react";
import Image from "next/image";
import {
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious,
} from "@/components/ui/carousel";
import { cn } from "@/lib/utils";
import MultipleSelector, { Option } from "@/components/ui/multiple-selector";
import { College, User } from "@prisma/client";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { addDormitorySchema } from "@/schema/addDormitorySchema";
import HeaderBtns from "./HeaderBtns";
import Header from "../../(components)/Header";
import { createDormitoryAction } from "@/actions/createDormitoryAction";
import { toast } from "sonner";

const OPTIONS: Option[] = [
  { label: "wifi", value: "wifi" },
  { label: "parking", value: "parking" },
  { label: "security", value: "security" },
  { label: "laundry", value: "laundry" },
  { label: "housekeeping", value: "houseKeeping" },
  { label: "gym", value: "gym" },
  { label: "power backup", value: "powerBackup" },
  { label: "mess", value: "mess" },
  { label: "attached bathroom", value: "attachedBathroom" },
  { label: "balcony", value: "balcony" },
  { label: "lift", value: "lift" },
  { label: "swimming pool", value: "swimmingPool" },
  { label: "sports", value: "sports" },
];

const CATEGORIES = ["HOSTEL", "APARTMENT", "PG"];

interface Variant {
  ac: string;
  seater: string;
  availableRooms: string;
  price: string;
}

interface Collegess {
  college: string;
  distance: string;
}

export default function AddDormitoryForm({
  users,
  collegesData,
}: {
  users: User[];
  collegesData: College[];
}) {
  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
    setError,
  } = useForm<addDormitorySchema>({
    resolver: zodResolver(addDormitorySchema), // Apply the zodResolver
  });
  const [variants, setVariants] = useState<Variant[]>([
    { ac: "", seater: "", availableRooms: "", price: "" },
  ]);
  const [colleges, setColleges] = useState<Collegess[]>([
    { college: "", distance: "" },
  ]);
  const [files, setFiles] = useState<any>([]);
  const [proofs, setProofs] = useState<any>([]);
  const [selectedFile, setSelectedFile] = useState(0);
  const [selectedCategory, setSelectedCategory] = useState("HOSTEL");
  const [selectedFacilities, setSelectedFacilities] = useState<string[]>([]);
  const [selectedManagers, setSelectedManagers] = useState<string[]>([]);
  const [selectedOwner, setSelectedOwner] = useState<string>("");

  const [minPrice, setMinPrice] = useState<number>(Infinity);
  const [maxPrice, setMaxPrice] = useState<number>(-Infinity);

  useEffect(() => {
    let min = Infinity;
    let max = -Infinity;

    for (const variant of variants) {
      const price = Number(variant.price);
      min = Math.min(min, price);
      max = Math.max(max, price);
    }

    setMinPrice(min);
    setMaxPrice(max);
  }, [variants]);
  const ctxProviderRef = useRef<any>(null);
  const ctxProviderRefProofs = useRef<any>(null);

  const usersData = users.map((user) => ({
    label: user.name,
    value: user.email,
  }));

  useEffect(() => {
    const ctxProvider = ctxProviderRef.current;
    if (!ctxProvider) return;

    const handleChangeEvent = (event: any) => {
      setFiles([
        ...event.detail.allEntries.filter(
          (file: any) => file.status === "success"
        ),
      ]);
    };

    ctxProvider.addEventListener("change", handleChangeEvent);

    return () => {
      ctxProvider.removeEventListener("change", handleChangeEvent);
    };
  }, [setFiles]);
  useEffect(() => {
    const ctxProvider = ctxProviderRefProofs.current;
    if (!ctxProvider) return;

    const handleChangeEvent = (event: any) => {
      setProofs([
        ...event.detail.allEntries.filter(
          (file: any) => file.status === "success"
        ),
      ]);
    };

    ctxProvider.addEventListener("change", handleChangeEvent);

    return () => {
      ctxProvider.removeEventListener("change", handleChangeEvent);
    };
  }, [setProofs]);

  const handleAddVariant = () => {
    setVariants([
      ...variants,
      { ac: "", seater: "", availableRooms: "", price: "" },
    ]);
  };

  const handleAddCollege = () => {
    setColleges([...colleges, { college: "", distance: "" }]);
  };

  const handleVariantChange = (
    index: number,
    field: keyof Variant,
    value: string
  ) => {
    const updatedVariants = [...variants];
    updatedVariants[index][field] = value;
    setVariants(updatedVariants);
  };
  const handleCollegeChange = (
    index: number,
    field: keyof Collegess,
    value: string
  ) => {
    const updatedColleges = [...colleges];
    updatedColleges[index][field] = value;
    setColleges(updatedColleges);
  };
  const handleDeleteVariant = (variantToDelete: Variant) => {
    setVariants(variants.filter((variant) => variant !== variantToDelete));
  };
  const handleDeleteColleges = (variantToDelete: Collegess) => {
    setColleges(colleges.filter((variant) => variant !== variantToDelete));
  };
  const myForm = useRef<HTMLFormElement>(null);

  const submitForm = () => {
    // The current property of the ref will be either HTMLFormElement or null.
    if (myForm.current !== null) {
      myForm.current.dispatchEvent(
        new Event("submit", { cancelable: true, bubbles: true })
      );
    }
  };
  const submitHandler = async (data: addDormitorySchema) => {
    try {
      const errors = [];

      if (!selectedCategory) errors.push("Category is required.");
      if (!selectedFacilities || selectedFacilities.length === 0)
        errors.push("At least one facility must be selected.");
      if (!selectedManagers || selectedManagers.length === 0)
        errors.push("At least one manager must be selected.");
      if (!selectedOwner) errors.push("Owner is required.");
      if (!files || files.length === 0)
        errors.push("At least one image is required.");
      if (
        !variants ||
        variants.some(
          (v) => v.seater == null || v.availableRooms == null || v.price == null
        )
      )
        errors.push("All variant fields must be filled correctly.");
      if (
        !colleges ||
        colleges.some(
          (c) => !c.college || c.distance == null || Number(c.distance) < 0
        )
      )
        errors.push("College details must be complete and correct.");
      if (minPrice == null || maxPrice == null || minPrice > maxPrice)
        errors.push("Valid price range is required.");

      if (errors.length > 0) {
        console.error("Validation errors:", errors);
        return; // Stop the submission if there are errors
      }
      const formData = {
        ...data,
        category: selectedCategory,
        facilities: selectedFacilities,
        managers: selectedManagers,
        owner: selectedOwner,
        images: files.map((file: any) => file.cdnUrl),
        variants: variants.map((variant) => ({
          ac: variant.ac === "AC" ? true : false,
          seater: Number(variant.seater),
          availableRooms: Number(variant.availableRooms),
          price: Number(variant.price),
        })),
        colleges: colleges.map((college) => ({
          collegeId: college.college,
          distance: college.distance,
        })),
        price: `${minPrice} - ${maxPrice}`,
        imageContext: JSON.stringify(files),
        proofs: proofs.map((proof: any) => proof.cdnUrl),
      };

      const result = await createDormitoryAction(formData);
      setFiles([]);
      setProofs([]);
      ctxProviderRef.current?.uploadCollection.clearAll();
      ctxProviderRefProofs.current?.uploadCollection.clearAll();
      toast.success("Dormitory added successfully");
    } catch (error: any) {
      console.log(error);
      toast.error("Failed to add dormitory");
      toast.error(error.message);
    }
  };
  return (
    <div className="space-y-6">
      <Header
        Button={<HeaderBtns onSave={submitForm} isSubmitting={isSubmitting} />}
        title="Add New Dormitory"
      />
      <form
        ref={myForm}
        className="grid grid-cols-1 lg:grid-cols-2 gap-6 w-full"
        onSubmit={handleSubmit(submitHandler)}
      >
        <div className="space-y-6">
          <Card className="h-fit">
            <CardHeader>
              <CardTitle>Dormitory Details</CardTitle>
              <CardDescription>
                Here you can add the details of the dormitory
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid gap-6">
                <div className="grid gap-3">
                  <Label
                    htmlFor="name"
                    className={cn("", {
                      "text-red-500": errors.name,
                    })}
                  >
                    {errors.name ? errors.name.message : "Name"}
                  </Label>
                  <Input
                    id="name"
                    {...register("name")}
                    className="w-full"
                    placeholder="Enter the name of the dormitory"
                  />
                </div>
                <div className="grid gap-3">
                  <Label
                    htmlFor="name"
                    className={cn("", {
                      "text-red-500": errors.address,
                    })}
                  >
                    {errors.address ? errors.address.message : "Address"}
                  </Label>
                  <Input
                    id="name"
                    {...register("address")}
                    className="w-full"
                    placeholder="Enter the address of the dormitory"
                  />
                </div>
                <div className="grid gap-3">
                  <Label
                    htmlFor="description"
                    className={cn("", {
                      "text-red-500": errors.description,
                    })}
                  >
                    {errors.description
                      ? errors.description.message
                      : "Description"}
                  </Label>
                  <Textarea
                    id="description"
                    {...register("description")}
                    placeholder="Enter the description of the dormitory"
                    className="min-h-32"
                  />
                </div>
                <div className="grid gap-3">
                  <Label
                    htmlFor="name"
                    className={cn("", {
                      "text-red-500": errors.bookingPrice,
                    })}
                  >
                    {errors.bookingPrice
                      ? errors.bookingPrice.message
                      : "Booking Price"}
                  </Label>
                  <Input
                    id="name"
                    {...register("bookingPrice", { valueAsNumber: true })}
                    type="number"
                    className="w-full"
                    placeholder="Enter the booking price of the dormitory"
                  />
                </div>
              </div>
            </CardContent>
          </Card>
          <Card className="h-fit">
            <CardHeader>
              <CardTitle>Capacity</CardTitle>
              <CardDescription>
                Here you can add the capacity of the dormitory
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-[150px]">S.No</TableHead>
                    <TableHead className="w-1/4">AC / NON AC</TableHead>
                    <TableHead className="w-1/4">Seater</TableHead>
                    <TableHead className="w-1/4">Available Rooms</TableHead>
                    <TableHead className="w-1/4">Price</TableHead>
                    {variants.length > 1 && <TableHead>Action</TableHead>}
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {variants.map((variant, index) => (
                    <TableRow key={index}>
                      <TableCell className="font-semibold">
                        {index + 1}
                      </TableCell>
                      <TableCell>
                        <Select
                          value={variant.ac}
                          onValueChange={(value) => {
                            handleVariantChange(index, "ac", value);
                          }}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Select" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="AC">AC</SelectItem>
                            <SelectItem value="NON-AC">NON AC</SelectItem>
                          </SelectContent>
                        </Select>
                      </TableCell>
                      <TableCell>
                        <Select
                          value={variant.seater}
                          onValueChange={(value) => {
                            handleVariantChange(index, "seater", value);
                          }}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Select" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="1">1</SelectItem>
                            <SelectItem value="2">2</SelectItem>
                            <SelectItem value="3">3</SelectItem>
                            <SelectItem value="4">4</SelectItem>
                            <SelectItem value="5">5</SelectItem>
                          </SelectContent>
                        </Select>
                      </TableCell>
                      <TableCell>
                        <Input
                          type="number"
                          value={variant.availableRooms}
                          onChange={(e) =>
                            handleVariantChange(
                              index,
                              "availableRooms",
                              e.target.value
                            )
                          }
                          min={"0"}
                          placeholder="No. of rooms available"
                        />
                      </TableCell>
                      <TableCell>
                        <Input
                          type="number"
                          value={variant.price}
                          onChange={(e) =>
                            handleVariantChange(index, "price", e.target.value)
                          }
                          placeholder="Price per year"
                          min={"0"}
                        />
                      </TableCell>
                      {variants.length > 1 && (
                        <TableCell>
                          <Button
                            variant="ghost"
                            className="text-red-500 text-xs"
                            onClick={() => handleDeleteVariant(variant)}
                            type="button"
                          >
                            <Trash />
                          </Button>
                        </TableCell>
                      )}
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
            <CardFooter className="justify-center border-t p-6">
              <Button
                size="sm"
                variant="ghost"
                type="button"
                className="gap-1"
                onClick={handleAddVariant}
              >
                <PlusCircle className="h-3.5 w-3.5" />
                Add Variant
              </Button>
            </CardFooter>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle>Dormitory Facilities</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="">
                <div className="grid gap-3">
                  <Label htmlFor="category">Facilities</Label>

                  <MultipleSelector
                    defaultOptions={OPTIONS}
                    onChange={(e) => {
                      const facilities = e.map((facility) => facility.value);
                      setSelectedFacilities(facilities);
                    }}
                    placeholder="Select facilities..."
                    emptyIndicator={
                      <p className="text-center text-lg leading-10 text-gray-600 dark:text-gray-400">
                        no results found.
                      </p>
                    }
                    aria-label="Select category"
                  />
                </div>
              </div>
            </CardContent>
          </Card>
          <Card className="h-fit">
            <CardHeader>
              <CardTitle>Dormitory Owner</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid gap-6">
                <div className="grid gap-3">
                  <Label htmlFor="status">Owner</Label>
                  <Select onValueChange={setSelectedOwner}>
                    <SelectTrigger id="status" aria-label="Select owner">
                      <SelectValue placeholder="Select owner" />
                    </SelectTrigger>
                    <SelectContent>
                      {users.map((user, index) => (
                        <SelectItem key={user.id} value={user.email}>
                          {user.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="grid gap-2 grid-cols-2">
                <div className="grid gap-3">
                  <Label
                    htmlFor="hospital"
                    className={cn("", {
                      "text-red-500": errors.addharCard,
                    })}
                  >
                    {errors.addharCard
                      ? errors.addharCard.message
                      : "Addhar Card"}
                  </Label>
                  <Input
                    id="hospital"
                    type="text"
                    placeholder="Enter 12 digit aadhar card number"
                    {...register("addharCard")}
                  />
                </div>
                <div className="grid gap-3">
                  <Label
                    htmlFor="market"
                    className={cn("", {
                      "text-red-500": errors.panCard,
                    })}
                  >
                    {errors.panCard ? errors.panCard.message : "PAN Card"}
                  </Label>
                  <Input
                    id="market"
                    placeholder="Enter 10 digit pan card number"
                    {...register("panCard")}
                  />
                </div>
              </div>
              <div className="grid gap-2 grid-cols-2">
                <div className="grid gap-3">
                  <Label
                    htmlFor="hospital"
                    className={cn("", {
                      "text-red-500": errors.ifscCode,
                    })}
                  >
                    {errors.ifscCode
                      ? errors.ifscCode.message
                      : "Bank Ifsc Code"}
                  </Label>
                  <Input
                    id="hospital"
                    placeholder="Enter 11 digit ifsc code"
                    {...register("ifscCode")}
                  />
                </div>
                <div className="grid gap-3">
                  <Label
                    htmlFor="market"
                    className={cn("", {
                      "text-red-500": errors.accountNumber,
                    })}
                  >
                    {errors.accountNumber
                      ? errors.accountNumber.message
                      : "Account Number"}
                  </Label>
                  <Input
                    id="market"
                    placeholder="Enter 16 digit account number"
                    {...register("accountNumber")}
                  />
                </div>
              </div>
              <div className="grid gap-2 grid-cols-2">
                <div className="grid gap-3">
                  <Label
                    htmlFor="hospital"
                    className={cn("", {
                      "text-red-500": errors.beneficiaryName,
                    })}
                  >
                    {errors.beneficiaryName
                      ? errors.beneficiaryName.message
                      : "Beneficiary Name"}
                  </Label>
                  <Input
                    id="hospital"
                    placeholder="Enter beneficiary name"
                    {...register("beneficiaryName")}
                  />
                </div>
                <div className="grid gap-3">
                  <Label
                    htmlFor="market"
                    className={cn("", {
                      "text-red-500": errors.distanceFromMarket,
                    })}
                  >
                    {errors.distanceFromMarket
                      ? errors.distanceFromMarket.message
                      : "Photo Proofs"}
                  </Label>
                  <lr-config
                    ctx-name="proofsUploader"
                    pubkey="7927fe6ba0130bf1d295"
                  />

                  <lr-file-uploader-regular ctx-name="proofsUploader" />

                  <lr-upload-ctx-provider
                    ctx-name="proofsUploader"
                    ref={ctxProviderRefProofs}
                  />
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle>Distance from</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid gap-2 grid-cols-2">
                <div className="grid gap-3">
                  <Label
                    htmlFor="hospital"
                    className={cn("", {
                      "text-red-500": errors.distanceFromHospital,
                    })}
                  >
                    {errors.distanceFromHospital
                      ? errors.distanceFromHospital.message
                      : "Hospital"}
                  </Label>
                  <Input
                    id="hospital"
                    type="number"
                    placeholder="Enter distance"
                    {...register("distanceFromHospital", {
                      valueAsNumber: true,
                    })}
                    min="0"
                  />
                </div>
                <div className="grid gap-3">
                  <Label
                    htmlFor="market"
                    className={cn("", {
                      "text-red-500": errors.distanceFromMarket,
                    })}
                  >
                    {errors.distanceFromMarket
                      ? errors.distanceFromMarket.message
                      : "Market"}
                  </Label>
                  <Input
                    id="market"
                    type="number"
                    placeholder="Enter distance"
                    min="0"
                    {...register("distanceFromMarket", {
                      valueAsNumber: true,
                    })}
                  />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
        <div className="space-y-6">
          <Card className="h-fit">
            <CardHeader>
              <CardTitle>Dormitory Category</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid gap-6">
                <div className="grid gap-3">
                  <Label htmlFor="status">Category</Label>
                  <Select onValueChange={setSelectedCategory}>
                    <SelectTrigger id="status" aria-label="Select category">
                      <SelectValue placeholder="Select category" />
                    </SelectTrigger>
                    <SelectContent>
                      {CATEGORIES.map((category, index) => (
                        <SelectItem key={index} value={category}>
                          {category}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card className="overflow-hidden h-fit">
            <CardHeader>
              <CardTitle>Dormitory Images</CardTitle>
              <CardDescription>
                Here you can add the images of the dormitory
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4">
                <div className="relative aspect-video overflow-hidden w-full rounded-md">
                  <Image
                    alt="Product image"
                    className="object-cover"
                    fill
                    src={files[selectedFile]?.cdnUrl ?? "/placeholder.svg"}
                  />
                </div>
                <div className="">
                  <Carousel>
                    <CarouselContent className="gap-4">
                      <CarouselItem className={cn("basis-2/5 select-none")}>
                        <div
                          className="flex aspect-video w-full items-center justify-center rounded-md border h-full border-dashed"
                          suppressHydrationWarning
                        >
                          <lr-config
                            ctx-name="my-uploader"
                            pubkey="7927fe6ba0130bf1d295"
                          />

                          <lr-file-uploader-regular ctx-name="my-uploader" />

                          <lr-upload-ctx-provider
                            ctx-name="my-uploader"
                            ref={ctxProviderRef}
                          />
                        </div>
                      </CarouselItem>

                      {files.length > 0 ? (
                        files.map((file: any, index: number) => (
                          <CarouselItem
                            className={cn(
                              "basis-2/5 select-none relative aspect-video overflow-hidden rounded-md border-2 border-transparent",
                              {
                                "border-primary rounded-md overflow-hidden":
                                  index === selectedFile,
                              }
                            )}
                            key={file.uuid}
                          >
                            <Image
                              className="object-cover"
                              src={file.cdnUrl ?? "/placeholder.svg"}
                              alt={
                                file.fileInfo.originalFilename ??
                                "Product image"
                              }
                              fill
                              onClick={() => setSelectedFile(index)}
                            />
                          </CarouselItem>
                        ))
                      ) : (
                        <>
                          <CarouselItem
                            className={cn(
                              "basis-2/5 relative aspect-video overflow-hidden rounded-md border-2 border-transparent select-none"
                            )}
                          >
                            <Image
                              alt="Product image"
                              className="aspect-video w-full rounded-md object-cover"
                              src="/placeholder.svg"
                              fill
                            />
                          </CarouselItem>
                          <CarouselItem
                            className={cn(
                              "basis-2/5 relative aspect-video overflow-hidden rounded-md border-2 border-transparent select-none"
                            )}
                          >
                            <Image
                              alt="Product image"
                              className="aspect-video w-full rounded-md object-cover"
                              fill
                              src="/placeholder.svg"
                            />
                          </CarouselItem>
                        </>
                      )}
                    </CarouselContent>
                  </Carousel>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle>Dormitory Managers</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="">
                <div className="grid gap-3">
                  <Label htmlFor="category">Managers</Label>

                  <MultipleSelector
                    defaultOptions={usersData}
                    placeholder="Select managers..."
                    onChange={(e) => {
                      const managers = e.map((manager) => manager.value);
                      setSelectedManagers(managers);
                    }}
                    emptyIndicator={
                      <p className="text-center text-lg leading-10 text-gray-600 dark:text-gray-400">
                        no results found.
                      </p>
                    }
                    aria-label="Select category"
                  />
                </div>
              </div>
            </CardContent>
          </Card>
          <Card className="h-fit">
            <CardHeader>
              <CardTitle>Nearby College</CardTitle>
              <CardDescription>
                Here you can add nearby college and distance.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-[150px]">S.No</TableHead>
                    <TableHead className="w-1/2">College</TableHead>
                    <TableHead className="w-1/2">Distance</TableHead>
                    {colleges.length > 1 && <TableHead>Action</TableHead>}
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {colleges.map((college, index) => (
                    <TableRow key={index}>
                      <TableCell className="font-semibold">
                        {index + 1}
                      </TableCell>
                      <TableCell>
                        <Select
                          value={college.college}
                          onValueChange={(value) => {
                            handleCollegeChange(index, "college", value);
                          }}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Select" />
                          </SelectTrigger>
                          <SelectContent>
                            {collegesData?.map((college, index) => (
                              <SelectItem key={college.id} value={college.id}>
                                {college.name}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </TableCell>

                      <TableCell>
                        <Input
                          type="number"
                          value={college.distance}
                          onChange={(e) =>
                            handleCollegeChange(
                              index,
                              "distance",
                              e.target.value
                            )
                          }
                          min={"0"}
                          placeholder="Distance in km"
                        />
                      </TableCell>
                      {colleges.length > 1 && (
                        <TableCell>
                          <Button
                            variant="ghost"
                            className="text-red-500 text-xs"
                            onClick={() => handleDeleteColleges(college)}
                            type="button"
                          >
                            <Trash />
                          </Button>
                        </TableCell>
                      )}
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
            <CardFooter className="justify-center border-t p-6">
              <Button
                size="sm"
                variant="ghost"
                type="button"
                className="gap-1"
                onClick={handleAddCollege}
              >
                <PlusCircle className="h-3.5 w-3.5" />
                Add College
              </Button>
            </CardFooter>
          </Card>
        </div>
      </form>
    </div>
  );
}

import React from "react";
import AddDormitoryForm from "./AddDormitoryForm";
import { prisma } from "@/lib/prisma/prisma";

export default async function page() {
  const users = await prisma.user.findMany({
    where: {
      NOT: {
        role: "ADMIN",
      },
    },
  });
  const colleges = await prisma.college.findMany();
  return (
    <div>
      <AddDormitoryForm users={users} collegesData={colleges} />
    </div>
  );
}

export const revalidate = 3600;

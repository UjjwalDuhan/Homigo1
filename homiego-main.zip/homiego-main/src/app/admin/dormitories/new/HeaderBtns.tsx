"use client";

import { Button } from "@/components/ui/button";
import Link from "next/link";
import { useRouter } from "next/navigation";
import React from "react";

export default function HeaderBtns({
  onSave,
  isSubmitting,
}: {
  onSave: () => void;
  isSubmitting: boolean;
}) {
  const router = useRouter();
  return (
    <div className="flex items-center gap-3">
      <Link href="/admin/dormitories">
        <Button variant={"outline"} disabled={isSubmitting}>
          Cancel
        </Button>
      </Link>
      <Button loading={isSubmitting} onClick={onSave}>
        Save
      </Button>
    </div>
  );
}

import React from "react";
import { prisma } from "@/lib/prisma/prisma";
import EditDormitoryForm from "./EditDormitoryForm";

export default async function Page({
  params,
  searchParams,
}: {
  params: { id: string };
  searchParams: { [key: string]: string | string[] | undefined };
}) {
  const users = await prisma.user.findMany({
    where: {
      NOT: {
        role: "ADMIN",
      },
    },
  });
  const colleges = await prisma.college.findMany();
  const dormitoryData = await prisma.dormitory.findFirst({
    where: {
      id: params.id,
    },
    include: {
      nearByColleges: true,
      variants: true,
      managers: true,
      owner: true,
      bankDetails: true,
    },
  });

  console.log(dormitoryData);
  return (
    <div>
      {dormitoryData && (
        <EditDormitoryForm
          users={users}
          collegesData={colleges}
          dormitoryData={dormitoryData}
          data={dormitoryData as any}
        />
      )}
    </div>
  );
}

export const revalidate = 3600;

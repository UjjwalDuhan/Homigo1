import React, { Suspense } from "react";
import Header from "../(components)/Header";
import AddCustomerBtn from "./AddCustomerBtn";
import DataTable from "../(components)/DataTable";
import { prisma, skipCondition } from "@/lib/prisma/prisma";
import { Skeleton } from "@/components/ui/skeleton";
import CustomerTable from "./CustomerTable";

const TableComp = async ({
  params,
  searchParams,
}: {
  params: { slug: string };
  searchParams: { [key: string]: string | string[] | undefined };
}) => {
  const search = (searchParams.q as string) ?? "";
  const sortBy = (searchParams.sortBy as string) || "updatedAt";
  const sortOrder = (searchParams.sortOrder as "asc" | "desc") ?? "desc";
  const rpp_user = Number(process.env.RPP_USER ?? searchParams.rpp ?? 10);
  const page = parseInt((searchParams.page as string) ?? "1");

  const whereClause: any = {
    ...(search.length > 1 && {
      OR: [
        {
          name: { contains: search, mode: "insensitive" },
        },
        {
          email: { contains: search, mode: "insensitive" },
        },
      ],
    }),
  };
  const reservedParams = ["page", "q", "update", "sortBy", "sortOrder", "rpp"];
  Object.entries(searchParams).forEach(([key, value]) => {
    if (!reservedParams.includes(key)) {
      whereClause[key] = value;
    }
  });
  const users = await prisma.user.findMany({
    where: whereClause,
    orderBy: { [sortBy]: sortOrder },
    skip: skipCondition({ page, rpp: rpp_user }),
    take: rpp_user,
  });
  const totalUsers = await prisma.user.count({
    where: whereClause,
  });
  const totalPages = Math.ceil(totalUsers / rpp_user);
  const filteredItems = users.length;
  return (
    <CustomerTable
      data={users}
      filteredItems={filteredItems}
      totalPages={totalPages}
      totalUsers={totalUsers}
    />
  );
};

const TableCompLoader = () => {
  return <Skeleton className="w-full h-32" />;
};

export default function Page({
  params,
  searchParams,
}: {
  params: { slug: string };
  searchParams: { [key: string]: string | string[] | undefined };
}) {
  const search = (searchParams.q as string) ?? "";
  const sortBy = (searchParams.sortBy as string) || "updatedAt";
  const sortOrder = (searchParams.sortOrder as "asc" | "desc") ?? "desc";
  const rpp_user = Number(process.env.RPP_USER ?? searchParams.rpp ?? 10);
  const page = parseInt((searchParams.page as string) ?? "1");
  return (
    <div className="space-y-6">
      <Header title="Customers List" Button={<AddCustomerBtn />} />
      <Suspense
        key={search + sortBy + sortOrder + rpp_user + page}
        fallback={<TableCompLoader />}
      >
        <TableComp params={params} searchParams={searchParams} />
      </Suspense>
    </div>
  );
}

import { Button } from "@/components/ui/button";
import Link from "next/link";
import React from "react";
import { FaPlus } from "react-icons/fa";

export default function AddCustomerBtn() {
  return (
    <Link href="/admin/users/new">
      <Button className="gap-3">
        <FaPlus />
        New User
      </Button>
    </Link>
  );
}

"use client";

import React, { useCallback } from "react";
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Checkbox } from "@/components/ui/checkbox";
import { Avatar } from "@radix-ui/react-avatar";
import { AvatarFallback } from "@/components/ui/avatar";
import { formatDate, getUserInitials } from "@/lib/utils";
import { prisma } from "../../../lib/prisma/prisma";
import { User } from "@prisma/client";
import { Button } from "@/components/ui/button";
import { ChevronLeftIcon, ChevronRightIcon, Edit2Icon } from "lucide-react";
import { MdDelete, MdModeEditOutline } from "react-icons/md";
import { Badge } from "@/components/ui/badge";
import { FaEye } from "react-icons/fa";
import { usePathname, useRouter, useSearchParams } from "next/navigation";
import Link from "next/link";
import page from "../dormitories/new/page";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  DoubleArrowLeftIcon,
  DoubleArrowRightIcon,
} from "@radix-ui/react-icons";
import { Skeleton } from "@/components/ui/skeleton";

const TableCompLoader = () => {
  return <Skeleton className="w-full h-32" />;
};

export default function DataTable({
  data,
  totalPages,
  filteredItems,
  totalUsers,
}: {
  data: User[];
  totalPages: number;
  filteredItems: number;
  totalUsers: number;
}) {
  const router = useRouter();
  const searchParams = useSearchParams();
  const path = usePathname();
  const page = parseInt(searchParams.get("page") ?? "1");
  const createQueryString = useCallback(
    (input: string | { [key: string]: string }, value?: string) => {
      const params = new URLSearchParams(searchParams.toString());

      if (typeof input === "string" && value !== undefined) {
        // Single key-value pair
        params.set(input, value);
      } else if (typeof input === "object") {
        // Multiple key-value pairs
        Object.entries(input).forEach(([key, val]) => {
          params.set(key, val);
        });
      }

      return params.toString();
    },
    [searchParams]
  );
  return (
    <div>
      <div className="rounded-md border overflow-hidden">
        <Table className="px-2">
          <TableHeader className="bg-muted px-2">
            <TableRow className="px-2">
              <TableHead className="pl-6 w-fit min-h-12">
                <div className="min-h-12 flex items-center">
                  <Checkbox />
                </div>
              </TableHead>
              <TableHead className="min-w-64">Customer</TableHead>
              <TableHead>Phone Number</TableHead>
              <TableHead>Role</TableHead>
              <TableHead>Registration Date</TableHead>
              <TableHead className="text-center">Action</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {data ? (
              data.length > 0 ? (
                data.map((user, index) => {
                  return (
                    <TableRow key={user.id} className="">
                      <TableCell className="pl-6">
                        <Checkbox />
                      </TableCell>
                      <TableCell className="">
                        <div className="flex items-center gap-3 min-h-12">
                          <Avatar className="cursor-pointer select-none size-10">
                            {/* <AvatarImage src="https://github.com/shadcn.png" /> */}
                            <AvatarFallback>
                              {getUserInitials(user.name)}
                            </AvatarFallback>
                          </Avatar>
                          <div>
                            <p className="capitalize">{user.name}</p>
                            <p className="text-xs text-muted-foreground">
                              {user.email}
                            </p>
                          </div>
                        </div>
                      </TableCell>

                      <TableCell>
                        {user.phoneNumber ?? "Not Provided"}
                      </TableCell>
                      <TableCell>
                        <Badge
                          variant={
                            user.role === "ADMIN"
                              ? "destructive"
                              : user.role === "OWNER"
                              ? "gradient"
                              : "secondary"
                          }
                        >
                          {user.role}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        {formatDate(new Date(user.createdAt))}
                      </TableCell>
                      <TableCell className="">
                        <div className="flex items-center gap-3 justify-center">
                          <Link href={`/admin/customers/${user.id}`}>
                            <Button className="">
                              <FaEye />
                            </Button>
                          </Link>
                          <Button className="">
                            <MdModeEditOutline />
                          </Button>
                          <Button className="">
                            <MdDelete />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  );
                })
              ) : (
                <TableRow className="text-center">
                  <p className="w-full h-12 flex items-center justify-center">
                    No results found!
                  </p>
                </TableRow>
              )
            ) : (
              <TableCompLoader />
            )}
          </TableBody>
        </Table>
      </div>
      <div className="flex justify-between items-center text-sm py-3">
        <div>
          <p>
            Showing {filteredItems} of {totalUsers}
          </p>
        </div>
        <div className="flex items-center gap-6">
          <div className="flex items-center gap-2">
            <p>Rows per page</p>
            <Select
              onValueChange={(e) => {
                router.push(path + "?" + createQueryString("rpp", e));
              }}
            >
              <SelectTrigger className="w-fit">
                <SelectValue placeholder="Select" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="10">10</SelectItem>
                <SelectItem value="20">20</SelectItem>
                <SelectItem value="30">30</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <p>
            Page {searchParams.get("page") ?? "1"} of {totalPages}
          </p>
          <div className="flex items-center space-x-2">
            <Button
              variant="outline"
              className="hidden h-8 w-8 p-0 lg:flex"
              onClick={() =>
                router.replace(path + "?" + createQueryString("page", `${1}`))
              }
              disabled={page === 1}
            >
              <span className="sr-only">Go to first page</span>
              <DoubleArrowLeftIcon className="h-4 w-4" />
            </Button>
            <Button
              variant="outline"
              className="h-8 w-8 p-0"
              onClick={() =>
                router.replace(
                  path + "?" + createQueryString("page", `${page - 1}`)
                )
              }
              disabled={page === 1}
            >
              <span className="sr-only">Go to previous page</span>
              <ChevronLeftIcon className="h-4 w-4" />
            </Button>
            <Button
              variant="outline"
              className="h-8 w-8 p-0"
              onClick={() =>
                router.replace(
                  path + "?" + createQueryString("page", `${page + 1}`)
                )
              }
              disabled={page === totalPages}
            >
              <span className="sr-only">Go to next page</span>
              <ChevronRightIcon className="h-4 w-4" />
            </Button>
            <Button
              variant="outline"
              className="hidden h-8 w-8 p-0 lg:flex"
              onClick={() =>
                router.replace(
                  path + "?" + createQueryString("page", `${totalPages}`)
                )
              }
              disabled={page === totalPages}
            >
              <span className="sr-only">Go to last page</span>
              <DoubleArrowRightIcon className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}

"use client";

import { Button } from "@/components/ui/button";
import React from "react";
import { FaPlus } from "react-icons/fa";
import {
  Breadcrumb,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbList,
  BreadcrumbPage,
  BreadcrumbSeparator,
} from "@/components/ui/breadcrumb";
import { usePathname } from "next/navigation";
import Link from "next/link";

const capitalizeFirstLetter = (string: string) => {
  return string.charAt(0).toUpperCase() + string.slice(1);
};

export default function Header({
  title,
  Button,
}: {
  title: string;
  Button: React.ReactNode;
}) {
  const path = usePathname();
  const pathnames = path.split("/").filter((x) => x && x !== "admin");
  return (
    <div className="flex justify-between items-center">
      <div>
        <h1 className="text-2xl font-semibold">{title}</h1>
        <Breadcrumb>
          <BreadcrumbList>
            <BreadcrumbItem>
              <BreadcrumbLink href="/admin">Home</BreadcrumbLink>
            </BreadcrumbItem>
            {pathnames.map((pathname, index) => {
              const route = `/admin/${pathnames.slice(0, index + 1).join("/")}`;
              const isLast = index === pathnames.length - 1;
              return (
                <React.Fragment key={route}>
                  <BreadcrumbSeparator />
                  <BreadcrumbItem>
                    {isLast ? (
                      <BreadcrumbPage>
                        {capitalizeFirstLetter(pathname)}
                      </BreadcrumbPage>
                    ) : (
                      <BreadcrumbLink href={route}>
                        {capitalizeFirstLetter(pathname)}
                      </BreadcrumbLink>
                    )}
                  </BreadcrumbItem>
                </React.Fragment>
              );
            })}
          </BreadcrumbList>
        </Breadcrumb>
      </div>
      {Button}
    </div>
  );
}

export default function Template({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-dvh w-full justify-center items-center flex bg-muted p-6">
      <div className="bg-white w-full min-h-96 p-6 rounded-xl">{children}</div>
    </div>
  );
}

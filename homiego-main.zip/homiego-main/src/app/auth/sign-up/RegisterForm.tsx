/* eslint-disable react/no-unescaped-entities */
"use client";

import { z } from "zod";
import { usePathname, useRouter, useSearchParams } from "next/navigation";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { signIn } from "next-auth/react";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import React from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import Link from "next/link";
import { Checkbox } from "@/components/ui/checkbox";
import { signUpSchema } from "@/schema/authSchema";
import axios from "axios";

const formSchema = z.object({
  email: z.string().min(2, {
    message: "Username must be at least 2 characters.",
  }),
  password: z.string(),
});

export default function RegisterForm() {
  const router = useRouter();
  const path = usePathname();
  const searchParams = useSearchParams();
  const form = useForm<z.infer<typeof signUpSchema>>({
    resolver: zodResolver(signUpSchema),
    defaultValues: {
      email: "",
      password: "",
      name: "",
      confirmPassword: "",
    },
  });

  const gg = async (formData: signUpSchema) => {
    await new Promise((resolve) => {
      setTimeout(resolve, 200);
    });
    const result: any = await axios.post(`/api/auth/sign-up`, formData);
    // Check if sign-in was successful
    if (result.error) {
      // Handle sign-in error (display error message, etc.)
      throw new Error(result.error);
    } else {
      // Sign-in was successful, handle redirect or other actions
      await signIn("credentials", {
        redirect: false, // Set to false to handle redirect manually
        email: formData.email,
        password: formData.password,
      });
      router.push("/");
    }
    return result;
  };

  // 2. Define a submit handler.
  async function onSubmit(data: z.infer<typeof signUpSchema>) {
    // Define a minimum delay of 0.8 seconds (2000 milliseconds)
    const minimumDelay = 800;

    // Delay the execution of gg function
    await new Promise((resolve) => {
      setTimeout(resolve, minimumDelay);
    });

    // Trigger the sign-in process
    const fg: any = gg(data);

    toast.promise(
      fg
        .then((result: any) => {
          // Handle success

          return result; // Pass the result to the success callback
        })
        .catch((error: any) => {
          // Handle error and get the error message
          return Promise.reject(error); // Pass the error to the error callback
        }),
      {
        loading: "Signing you in...",
        error: (error) => {
          // Display the error message using toast.error
          return error.message; // Return the error message
        },
        success: "Sign Up Successfully....",
      }
    );
  }
  const login = async (provider: string) => {
    try {
      const result = await signIn(provider, {
        callbackUrl: process.env.NEXT_PUBLIC_URL,
        redirect: false,
      });
      toast.loading("Logging in...!");
    } catch (error: any) {
      // Handle errors, possibly by displaying an error message using toast.error() or other means
      toast.error(`Error: ${error.message}`);
    }
  };
  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
        <FormField
          control={form.control}
          name="name"
          render={({ field }) => (
            <FormItem>
              <FormMessage className="text-right" />
              <FormControl className="focus-within:border-primary">
                <Input
                  placeholder="Please enter your name..."
                  className="h-11"
                  type="text"
                  {...field}
                />
              </FormControl>
            </FormItem>
          )}
        />
        <FormField
          control={form.control}
          name="email"
          render={({ field }) => (
            <FormItem>
              <FormMessage className="text-right" />
              <FormControl className="focus-within:border-primary">
                <Input
                  placeholder="Please enter your email address..."
                  className="h-11"
                  type="email"
                  {...field}
                />
              </FormControl>
            </FormItem>
          )}
        />
        <FormField
          control={form.control}
          name="password"
          render={({ field }) => (
            <FormItem>
              <FormMessage className="text-right" />
              <FormControl className="focus-within:border-primary">
                <Input
                  placeholder="Please enter your password..."
                  className="h-11"
                  type="password"
                  {...field}
                />
              </FormControl>
            </FormItem>
          )}
        />
        <FormField
          control={form.control}
          name="confirmPassword"
          render={({ field }) => (
            <FormItem>
              <FormMessage className="text-right" />
              <FormControl className="focus-within:border-primary">
                <Input
                  placeholder="Please enter your password again..."
                  className="h-11"
                  type="password"
                  {...field}
                />
              </FormControl>
            </FormItem>
          )}
        />
        <div className="flex pb-2 justify-between items-center text-sm "></div>
        <Button type="submit" size={"default"} className="w-full">
          Sign up
        </Button>
        <p className="w-full text-center text-sm text-muted-foreground">
          Already have an account?{" "}
          <Link className="font-medium text-black" href={"/auth/login"}>
            Log in
          </Link>
        </p>
      </form>
    </Form>
  );
}

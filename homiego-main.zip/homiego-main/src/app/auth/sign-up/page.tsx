import { Button } from "@/components/ui/button";
import React from "react";
import * as Icon from "react-icons/fc";
import * as FaIcon from "react-icons/fa";
import { IoLogoWebComponent } from "react-icons/io5";
import Link from "next/link";
import RegisterForm from "./RegisterForm";

export default function Page() {
  return (
    <div className="h-full w-full space-y-4">
      <div className="w-full flex space-y-4 flex-col justify-center items-center">
        <Link
          href={"/"}
          className="h-12 w-12 flex items-center justify-center bg-secondary rounded-full"
        >
          <IoLogoWebComponent className="text-3xl" />
        </Link>
        <div className="text-center">
          <h2 className="text-xl font-medium">Create your account</h2>
          <p className="text-muted-foreground text-sm">
            Enter the fields below to get started.
          </p>
        </div>
        <div className="w-full flex items-center gap-3">
          <Button variant={"outline"} className="w-full">
            <Icon.FcGoogle className="text-lg" />
          </Button>
          <Button disabled variant={"outline"} className="w-full">
            <FaIcon.FaFacebook className="text-lg" />
          </Button>
        </div>
        <div className="flex items-center w-full gap-2">
          <hr className="w-full" />
          <span className="text-muted-foreground text-sm">OR</span>
          <hr className="w-full" />
        </div>
      </div>
      <RegisterForm />
    </div>
  );
}

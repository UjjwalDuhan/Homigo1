/* eslint-disable react/no-unescaped-entities */
"use client";

import { z } from "zod";
import { usePathname, useRouter, useSearchParams } from "next/navigation";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { signIn } from "next-auth/react";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import React from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import Link from "next/link";
import { Checkbox } from "@/components/ui/checkbox";

const formSchema = z.object({
  email: z.string().min(2, {
    message: "Username must be at least 2 characters.",
  }),
  password: z.string(),
});

export default function LoginForm() {
  const router = useRouter();
  const path = usePathname();
  const searchParams = useSearchParams();
  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      email: "",
      password: "",
    },
  });

  const gg = async (email: string, password: string) => {
    await new Promise((resolve) => {
      setTimeout(resolve, 200);
    });
    const result: any = await signIn("credentials", {
      redirect: false, // Set to false to handle redirect manually
      email,
      password,
    });
    // Check if sign-in was successful
    if (result.error) {
      // Handle sign-in error (display error message, etc.)
      // console.log(result);
      // toast.error(result.error);
      throw new Error(result.error);
    } else {
      // Sign-in was successful, handle redirect or other actions
      router.refresh();
      router.replace(searchParams.get("callbackUrl") || "/");
      location.reload();
    }
    return result;
  };
  async function onSubmit(data: z.infer<typeof formSchema>) {
    const { email, password } = data;

    // Define a minimum delay of 0.8 seconds (2000 milliseconds)
    const minimumDelay = 800;

    // Delay the execution of gg function
    await new Promise((resolve) => {
      setTimeout(resolve, minimumDelay);
    });

    // Trigger the sign-in process
    const fg: any = gg(email, password);

    toast.promise(
      fg
        .then((result: any) => {
          // Handle success

          return result; // Pass the result to the success callback
        })
        .catch((error: any) => {
          // Handle error and get the error message
          console.error(error.message);
          return Promise.reject(error); // Pass the error to the error callback
        }),
      {
        loading: "Logging you in...",
        error: (error) => {
          // Display the error message using toast.error
          // toast.error(error.message);
          return "Credentials do not match!"; // Return the error message
        },
        success: "Logged In Successfully....",
      }
    );
  }
  const login = async (provider: string) => {
    try {
      const result = await signIn(provider, {
        callbackUrl: process.env.NEXT_PUBLIC_URL,
        redirect: false,
      });
      toast.loading("Logging in...!");
    } catch (error: any) {
      // Handle errors, possibly by displaying an error message using toast.error() or other means
      toast.error(`Error: ${error.message}`);
    }
  };
  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
        <FormField
          control={form.control}
          name="email"
          render={({ field }) => (
            <FormItem>
              <FormMessage className="text-right" />
              <FormControl className="focus-within:border-primary">
                <Input
                  placeholder="Please enter your email address..."
                  className="h-11"
                  type="email"
                  {...field}
                />
              </FormControl>
            </FormItem>
          )}
        />
        <FormField
          control={form.control}
          name="password"
          render={({ field }) => (
            <FormItem>
              <FormMessage className="text-right" />
              <FormControl className="focus-within:border-primary">
                <Input
                  placeholder="Please enter your password..."
                  className="h-11"
                  type="password"
                  {...field}
                />
              </FormControl>
            </FormItem>
          )}
        />
        <div className="flex pb-2 justify-between items-center text-sm ">
          <div className="flex items-center space-x-2">
            <Checkbox id="remember_me_login" defaultChecked />
            <label
              htmlFor="remember_me_login"
              className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
            >
              Remember me
            </label>
          </div>
          <Link
            href={"/auth/forgot-password"}
            className="font-medium underline underline-offset-1"
          >
            Forgot Password?
          </Link>
        </div>
        <Button type="submit" size={"default"} className="w-full">
          Login
        </Button>
        <p className="w-full text-center text-sm text-muted-foreground">
          Don't have an account yet?{" "}
          <Link className="font-medium text-black" href={"/auth/sign-up"}>
            Sign up
          </Link>
        </p>
      </form>
    </Form>
  );
}

import { getSession } from "next-auth/react";
import React from "react";
import { redirect } from "next/navigation";
import { auth } from "@/auth";

export default async function Layout({
  children,
}: {
  children: React.ReactNode;
}) {
  const session: any = await auth();
  if (session) {
    redirect("/");
  }
  return <>{children}</>;
}

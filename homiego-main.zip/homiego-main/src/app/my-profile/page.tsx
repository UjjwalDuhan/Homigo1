import { auth } from "@/auth";
import { Button } from "@/components/ui/button";
import MaxWidthWrapper from "@/components/wrappers/MaxWidthWrapper";
import { getUserInitials } from "@/lib/utils";
import Link from "next/link";
import React from "react";
import { FaChevronRight } from "react-icons/fa";
import { IoMdPerson } from "react-icons/io";
import { IoExit } from "react-icons/io5";

import {
  Drawer,
  DrawerClose,
  DrawerContent,
  DrawerDescription,
  DrawerFooter,
  DrawerHeader,
  DrawerTitle,
  DrawerTrigger,
} from "@/components/ui/drawer";
import LogoutBtn from "./LogoutBtn";
import {
  MdAdminPanelSettings,
  MdPrivacyTip,
  MdReviews,
  MdSecurity,
} from "react-icons/md";

export default async function page() {
  const session = await auth();
  return (
    <div>
      <MaxWidthWrapper>
        <div>
          <div className="flex items-center justify-center flex-col my-3 mb-8">
            <div className="size-20 text-xl font-bold bg-muted rounded-full flex items-center justify-center mb-2">
              {getUserInitials(session?.user.name ?? "")}
            </div>
            <p className="text-xl font-semibold">{session?.user.name}</p>
            <p className="text-sm font-medium text-muted-foreground">
              {session?.user.email}
            </p>
          </div>
          <div className="space-y-3">
            <Link
              href={"/my-profile/personal-info"}
              className="flex items-center justify-between"
            >
              <div className="flex items-center gap-3">
                <IoMdPerson className="text-2xl" />
                <p className="font-medium text-base">Personal Info</p>
              </div>
              <Button size={"icon"} variant={"ghost"}>
                <FaChevronRight />
              </Button>
            </Link>
            <Link
              href={"/my-profile/privacy-sharing"}
              className="flex items-center justify-between"
            >
              <div className="flex items-center gap-3">
                <MdPrivacyTip className="text-2xl" />
                <p className="font-medium text-base">Privacy & Sharing</p>
              </div>
              <Button size={"icon"} variant={"ghost"}>
                <FaChevronRight />
              </Button>
            </Link>
            <Link
              href={"/my-profile/security"}
              className="flex items-center justify-between"
            >
              <div className="flex items-center gap-3">
                <MdSecurity className="text-2xl" />
                <p className="font-medium text-base">Security</p>
              </div>
              <Button size={"icon"} variant={"ghost"}>
                <FaChevronRight />
              </Button>
            </Link>
            <Link
              href={"/my-profile/reviews"}
              className="flex items-center justify-between"
            >
              <div className="flex items-center gap-3">
                <MdReviews className="text-2xl" />
                <p className="font-medium text-base">Reviews</p>
              </div>
              <Button size={"icon"} variant={"ghost"}>
                <FaChevronRight />
              </Button>
            </Link>
            {session?.user.role === "ADMIN" && (
              <Link
                href={"/admin"}
                className="flex items-center justify-between"
              >
                <div className="flex items-center gap-3">
                  <MdAdminPanelSettings className="text-2xl" />
                  <p className="font-medium text-base">Admin Panel</p>
                </div>
                <Button size={"icon"} variant={"ghost"}>
                  <FaChevronRight />
                </Button>
              </Link>
            )}
            <Drawer>
              <DrawerTrigger asChild>
                <div className="flex items-center justify-between text-destructive cursor-pointer">
                  <div className="flex items-center gap-3 text-destructive">
                    <IoExit className="text-2xl" />
                    <p className="font-medium text-base">Log out</p>
                  </div>
                  <Button size={"icon"} variant={"ghost"}>
                    <FaChevronRight />
                  </Button>
                </div>
              </DrawerTrigger>
              <DrawerContent>
                <DrawerHeader>
                  <DrawerTitle>Are you sure?</DrawerTitle>
                  <DrawerDescription>
                    You can login again anytime.
                  </DrawerDescription>
                </DrawerHeader>
                <DrawerFooter>
                  <LogoutBtn />
                  <DrawerClose>
                    <Button variant="outline">Cancel</Button>
                  </DrawerClose>
                </DrawerFooter>
              </DrawerContent>
            </Drawer>
          </div>
        </div>
      </MaxWidthWrapper>
    </div>
  );
}

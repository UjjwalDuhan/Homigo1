"use client";

import { Button } from "@/components/ui/button";
import { signOut } from "next-auth/react";
import { useRouter } from "next/navigation";
import React from "react";

export default function LogoutBtn() {
  const router = useRouter();
  return (
    <Button
      onClick={() => {
        signOut({
          redirect: true,
          callbackUrl: "/",
        });
      }}
    >
      Log out
    </Button>
  );
}

import { Button } from "@/components/ui/button";
import Image from "next/image";
import React from "react";
import { IoHeart, IoHeartOutline } from "react-icons/io5";
import { TbAirConditioning } from "react-icons/tb";
import { IoBedSharp } from "react-icons/io5";
import formatPrice from "../../lib/utils";
import Link from "next/link";
import { Dormitory, variant } from "@prisma/client";
import { auth } from "@/auth";

export default async function FeaturedCard({
  data,
  dat,
}: {
  data: Dormitory;
  dat: any;
}) {
  const priceArray = data.price.split("-");
  const minPrice = formatPrice(Number(priceArray[0]));
  const session = await auth();
  function findMinAndMaxSeater() {
    // Initialize with very high or very low initial values
    const initial = { minSeater: Infinity, maxSeater: -Infinity };

    // Use reduce to find min and max
    const result = dat.variants.reduce((acc: any, variant: any) => {
      if (variant.seater < acc.minSeater) {
        acc.minSeater = variant.seater;
      }
      if (variant.seater > acc.maxSeater) {
        acc.maxSeater = variant.seater;
      }
      return acc;
    }, initial);

    return result;
  }
  const seaterExtremes = findMinAndMaxSeater();
  return (
    <div className="flex flex-col space-y-3 w-full">
      <Link
        href={`/dormitory/${data.id}`}
        className="relative w-full aspect-video rounded-xl overflow-hidden"
      >
        <Image
          src={data.images[0] ?? "/home_page_images/dummy_hostel.jpg"}
          alt={"Flat"}
          fill
          className="object-cover"
        />
        <Button
          size={"icon"}
          variant={"outline"}
          className="absolute top-2.5 right-2.5 rounded-full hover:text-primary active:text-primary"
        >
          <IoHeartOutline className="text-xl" />
        </Button>
        <div className="absolute bottom-2.5 left-2.5 bg-opacity-30 backdrop-blur-lg text-white px-4 rounded-lg py-2 text-base font-medium">
          {minPrice} onwards
        </div>
      </Link>
      <div>
        <h1 className="text-lg font-semibold">{data.name}</h1>
        <p className="text-sm font-medium text-gray-500">
          {dat.nearByColleges[0].distance} km away
        </p>
        <div className="flex items-center justify-between mt-1">
          {dat.variants.some((variant: variant) => variant.ac === true) ? (
            <div className="flex items-center gap-2 text-sm font-medium">
              <TbAirConditioning className="text-xl" />
              <p>Air Conditioned</p>
            </div>
          ) : null}

          <div className="flex items-center gap-2 text-sm font-medium">
            <IoBedSharp className="text-xl" />
            <p>
              {seaterExtremes.minSeater} - {seaterExtremes.maxSeater} Seater
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

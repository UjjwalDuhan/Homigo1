"use client";

import React from "react";
import { ToggleGroup, ToggleGroupItem } from "@/components/ui/toggle-group";
import Image from "next/image";
import { usePathname, useRouter } from "next/navigation";

const data = [
  {
    label: "Hostel",
    image: "/home_page_images/hostel.png",
  },
  {
    label: "PG",
    image: "/home_page_images/pg.png",
  },
  {
    label: "Apartment",
    image: "/home_page_images/flat.png",
  },
];

const ToggleCompIndividual = ({
  label,
  image,
}: {
  label: string;
  image: string;
}) => {
  return (
    <div className="w-full h-full flex flex-col justify-center items-center gap-2">
      <Image
        src={image}
        alt={label}
        width={50}
        height={50}
        className="object-cover"
      />
      <p>{label}</p>
    </div>
  );
};

export default function ToggleComp() {
  const router = useRouter();
  const pathname = usePathname();
  return (
    <div>
      <ToggleGroup
        type="single"
        className="gap-3 grid grid-cols-3"
        defaultValue="hostel"
        onValueChange={(e) => {
          router.replace(`${pathname}?category=${e.toUpperCase()}`);
        }}
      >
        {data.map((item, index) => (
          <ToggleGroupItem
            key={index}
            value={item.label.toLowerCase()}
            aria-label={item.label}
            className="w-full h-28 border"
            // asChild
          >
            <ToggleCompIndividual label={item.label} image={item.image} />
          </ToggleGroupItem>
        ))}
      </ToggleGroup>
    </div>
  );
}

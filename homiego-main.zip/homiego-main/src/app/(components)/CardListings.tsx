import { Button } from "@/components/ui/button";
import MaxWidthWrapper from "@/components/wrappers/MaxWidthWrapper";
import React, { Suspense } from "react";
import DormitoryCard from "./DormitoryCard";
import { Skeleton } from "@/components/ui/skeleton";
import { prisma } from "@/lib/prisma/prisma";

const Loader = () => (
  <>
    <Skeleton className=" w-full h-28 rounded-xl overflow-hidden" />
    <Skeleton className=" w-full h-28 rounded-xl overflow-hidden" />
    <Skeleton className=" w-full h-28 rounded-xl overflow-hidden" />
    <Skeleton className=" w-full h-28 rounded-xl overflow-hidden" />
    <Skeleton className=" w-full h-28 rounded-xl overflow-hidden" />
  </>
);

const Listings = async ({
  searchParams,
}: {
  searchParams: { [key: string]: string | string[] | undefined };
}) => {
  const data = await prisma.dormitory.findMany({
    where: {
      status: "ACTIVE",
      category: (searchParams.category as string) ?? "HOSTEL",
    },
    include: {
      nearByColleges: true,
      variants: true,
    },
    take: 5,
  });
  return (
    <>
      {data.map((dormitory) => (
        <DormitoryCard data={dormitory} dat={dormitory} key={dormitory.id} />
      ))}
    </>
  );
};

export default function CardListings({
  title,
  feature,
  searchParams,
}: {
  title: string;
  feature: string;
  searchParams: { [key: string]: string | string[] | undefined };
}) {
  return (
    <div>
      <MaxWidthWrapper>
        <div className="space-y-1.5">
          <div className="flex items-center justify-between">
            <h1 className="text-xl font-semibold">{title}</h1>
            <Button variant={"ghost"}>View All</Button>
          </div>
          <div className="space-y-3">
            <Suspense fallback={<Loader />}>
              <Listings searchParams={searchParams} />
            </Suspense>
          </div>
        </div>
      </MaxWidthWrapper>
    </div>
  );
}

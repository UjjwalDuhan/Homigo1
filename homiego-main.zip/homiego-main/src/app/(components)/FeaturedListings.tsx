import { Button } from "@/components/ui/button";
import React, { Suspense } from "react";
import { Card, CardContent } from "@/components/ui/card";
import {
  Carousel,
  CarouselContent,
  CarouselItem,
} from "@/components/ui/carousel";
import FeaturedCard from "./FeaturedCard";
import { cn } from "@/lib/utils";
import { prisma } from "@/lib/prisma/prisma";
import { Dormitory } from "@prisma/client";
import { Skeleton } from "@/components/ui/skeleton";

const Listings = async ({
  params,
  searchParams,
}: {
  params: { id: string };
  searchParams: { [key: string]: string | string[] | undefined };
}) => {
  const category = searchParams.category ? searchParams.category : "HOSTEL";
  const data = await prisma.dormitory.findMany({
    where: {
      status: "ACTIVE",
      category: category as string,
    },
    include: {
      nearByColleges: true,
      variants: true,
    },
    take: 5,
  });

  return (
    <>
      {data.map((dormitory: Dormitory) => {
        return (
          <CarouselItem key={dormitory.id} className={cn("basis-10/12")}>
            <div className={cn("p-0.5")}>
              <FeaturedCard data={dormitory} dat={dormitory} />
            </div>
          </CarouselItem>
        );
      })}
    </>
  );
};

const Loader = () => {
  return (
    <>
      <CarouselItem className={cn("basis-10/12")}>
        <div className={cn("p-0.5")}>
          <Skeleton className="w-full h-56 rounded-xl overflow-hidden" />
        </div>
      </CarouselItem>
      <CarouselItem className={cn("basis-10/12")}>
        <div className={cn("p-0.5")}>
          <Skeleton className="w-full h-56 rounded-xl overflow-hidden" />
        </div>
      </CarouselItem>
      <CarouselItem className={cn("basis-10/12")}>
        <div className={cn("p-0.5")}>
          <Skeleton className="w-full h-56 rounded-xl overflow-hidden" />
        </div>
      </CarouselItem>
      <CarouselItem className={cn("basis-10/12")}>
        <div className={cn("p-0.5")}>
          <Skeleton className="w-full h-56 rounded-xl overflow-hidden" />
        </div>
      </CarouselItem>
    </>
  );
};

export default async function FeaturedListings({
  params,
  searchParams,
}: {
  params: { id: string };
  searchParams: { [key: string]: string | string[] | undefined };
}) {
  return (
    <div className="space-y-1">
      <div className="flex items-center justify-between pr-6">
        <h1 className="text-xl font-semibold">Featured Listings</h1>
        <Button variant={"ghost"}>View All</Button>
      </div>
      <Carousel
        opts={{
          align: "start",
        }}
        className="w-full"
      >
        <CarouselContent>
          <Suspense fallback={<Loader />}>
            <Listings searchParams={searchParams} params={params} />
          </Suspense>
        </CarouselContent>
      </Carousel>
    </div>
  );
}

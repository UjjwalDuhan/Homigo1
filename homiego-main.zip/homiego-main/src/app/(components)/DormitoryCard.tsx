import Image from "next/image";
import Link from "next/link";
import React from "react";
import { Button } from "@/components/ui/button";
import { IoBedSharp, IoHeartOutline } from "react-icons/io5";
import formatPrice from "@/lib/utils";
import { TbAirConditioning } from "react-icons/tb";
import { IoMdPin } from "react-icons/io";
import { Dormitory } from "@prisma/client";

export default function DormitoryCard({
  data,
  dat,
}: {
  data: Dormitory;
  dat: any;
}) {
  const priceArray = data.price.split("-");
  const minPrice = formatPrice(Number(priceArray[0]));
  return (
    <div className="flex items-center gap-3">
      <Link
        href={`/dormitory/${data.id}`}
        className="relative w-[44%] min-w-44 aspect-video rounded-xl overflow-hidden"
      >
        <Image
          src={data.images[0] ?? "/home_page_images/dummy_hostel.jpg"}
          alt={"Flat"}
          fill
          className="object-cover"
        />
        <Button
          size={"icon"}
          variant={"outline"}
          className="absolute size-6 text-sm top-2.5 right-2.5 rounded-full hover:text-primary active:text-primary"
        >
          <IoHeartOutline />
        </Button>
      </Link>
      <div>
        <h1 className="text-lg font-semibold truncate max-w-40">{data.name}</h1>

        <p className="text-base font-medium">{minPrice} onwards</p>
        <div className="flex items-center justify-between mt-1">
          <div className="flex items-center gap-2 text-base font-medium">
            <TbAirConditioning />
            <IoBedSharp />
            <p className="text-sm flex gap-1 items-center">
              <IoMdPin />
              {dat.nearByColleges[0].distance} km away
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

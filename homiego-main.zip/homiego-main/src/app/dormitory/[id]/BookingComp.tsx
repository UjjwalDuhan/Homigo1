"use client";

import { Button } from "@/components/ui/button";
import formatPrice from "@/lib/utils";
import React from "react";
import {
  Drawer,
  DrawerClose,
  DrawerContent,
  DrawerDescription,
  DrawerFooter,
  DrawerHeader,
  DrawerTitle,
  DrawerTrigger,
} from "@/components/ui/drawer";
import MaxWidthWrapper from "@/components/wrappers/MaxWidthWrapper";
import { Dormitory } from "@prisma/client";

export default function BookingComp({
  data,
  dormitory,
}: {
  data: any;
  dormitory: Dormitory;
}) {
  const [price, setPrice] = React.useState(0);
  const priceArray = data.price.split("-");
  const minPrice = formatPrice(Number(priceArray[0]));
  return (
    <div className="h-20 bg-background flex items-center justify-between">
      <div>
        <p className="text-sm font-medium text-muted-foreground">
          Booking Price
        </p>
        <p className="text-xl font-semibold">
          {formatPrice(dormitory.bookingPrice)}
        </p>
      </div>

      <Drawer>
        <DrawerTrigger asChild>
          <Button variant={"gradient"} size={"lg"}>
            Book Now
          </Button>
        </DrawerTrigger>
        <DrawerContent>
          <div className="min-h-96">
            <MaxWidthWrapper>
              <div className="h-20 flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">
                    Booking Price
                  </p>
                  <p className="text-xl font-semibold">{formatPrice(12000)}</p>
                </div>
                <Button variant={"gradient"} size={"lg"}>
                  Book Now
                </Button>
              </div>
            </MaxWidthWrapper>
          </div>
        </DrawerContent>
      </Drawer>
    </div>
  );
}

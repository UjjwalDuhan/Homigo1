"use client";

import React from "react";
import {
  Carousel,
  CarouselApi,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious,
} from "@/components/ui/carousel";
import { cn } from "@/lib/utils";
import Image from "next/image";
import Autoplay from "embla-carousel-autoplay";

export default function ImageSlider({ images }: { images: string[] }) {
  const [api, setApi] = React.useState<CarouselApi>();
  const [current, setCurrent] = React.useState(0);
  const [count, setCount] = React.useState(0);
  const [api2, setApi2] = React.useState<CarouselApi>();

  React.useEffect(() => {
    if (!api || !api2) {
      return;
    }

    setCount(api.scrollSnapList().length);
    setCurrent(api.selectedScrollSnap() + 1);
    console.log("hi");
    api.on("select", () => {
      setCurrent(api.selectedScrollSnap() + 1);
    });
  }, [api]);

  React.useEffect(() => {
    if (!api2) {
      return;
    }
    api2.scrollTo(current - 1);
  }, [current, api2]);
  return (
    <>
      <Carousel
        setApi={setApi}
        // plugins={[
        //   Autoplay({
        //     delay: 5000,
        //   }),
        // ]}
        opts={{
          align: "start",
          loop: true,
        }}
        className="w-full"
      >
        <CarouselContent>
          {images.map((image, index) => (
            <CarouselItem key={index} className={cn("")}>
              <div className={cn("p-0.5 relative w-full aspect-video")}>
                <Image
                  src={image ?? "/home_page_images/dummy_hostel.jpg"}
                  fill
                  alt="hg"
                  className="object-cover rounded-lg"
                />
              </div>
            </CarouselItem>
          ))}
        </CarouselContent>
      </Carousel>
      <Carousel
        opts={{
          align: "start",
        }}
        setApi={setApi2}
        className="w-full"
      >
        <CarouselContent>
          {images.map((image, index) => (
            <CarouselItem key={index} className={cn("basis-5/12")}>
              <div
                key={index}
                className={cn(
                  "p-0.5 relative w-full transition-all aspect-video border-2 border-transparent hover:border-primary cursor-pointer overflow-hidden rounded-lg",
                  {
                    "border-primary": current === index + 1,
                  }
                )}
                onClick={() => {
                  api?.scrollTo(index);
                  api2?.scrollTo(index);
                }}
              >
                <Image
                  src={image ?? "/home_page_images/dummy_hostel.jpg"}
                  fill
                  alt="hg"
                  className="object-cover"
                />
              </div>
            </CarouselItem>
          ))}
        </CarouselContent>
      </Carousel>
    </>
  );
}

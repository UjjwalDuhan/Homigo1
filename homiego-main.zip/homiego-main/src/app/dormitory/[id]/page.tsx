import MaxWidthWrapper from "@/components/wrappers/MaxWidthWrapper";
import React from "react";
import ImageSlider from "./ImageSlider";
import { Button } from "@/components/ui/button";
import { IoFastFood, IoHeart, IoHeartOutline, IoWifi } from "react-icons/io5";
import { Ratings } from "@/components/ui/ratings";
import { SeparatorVertical } from "lucide-react";
import { Separator } from "@/components/ui/separator";
import formatPrice from "@/lib/utils";
import BookingComp from "./BookingComp";
import {
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious,
} from "@/components/ui/carousel";
import { GiWashingMachine } from "react-icons/gi";
import { FaDumbbell, FaSwimmer } from "react-icons/fa";
import { prisma } from "@/lib/prisma/prisma";
import { Metadata, ResolvingMetadata } from "next";

type Params = {
  id: string;
};

type Props = {
  params: Params;
  searchParams: { [key: string]: string | string[] | undefined };
};

export async function generateMetadata(
  { params, searchParams }: Props,
  parent: ResolvingMetadata
): Promise<Metadata> {
  const { id } = params;

  const dormitory = await prisma.dormitory.findFirst({
    where: {
      id,
    },
    include: {
      owner: true,
    },
  });

  return {
    title: `${dormitory?.name}`,
    authors: [
      {
        name: dormitory?.owner.name || "Harshit Sharma",
      },
    ],
    description: dormitory?.description,
    // keywords: dormitory.keywords,
    openGraph: {
      title: `${dormitory?.name}`,
      description: dormitory?.description,
      type: "article",
      url: `https://homiego.in/dormitory/${dormitory?.id}`,
      publishedTime: String(dormitory?.createdAt),
      modifiedTime: String(dormitory?.updatedAt),
      authors: ["https://homiego.in"],
      // tags: post.categories,
      images: [
        {
          url: `${dormitory?.images[0]}`,
          width: 1024,
          height: 576,
          // alt: post.title,
          type: "image/png",
        },
      ],
    },
    alternates: {
      canonical: `https://homiego.in/dormitory/${dormitory?.id}`,
    },
  };
}

const facilities = [
  {
    icon: IoWifi,
    label: "Wifi",
  },
  {
    icon: IoFastFood,
    label: "Mess",
  },
  {
    icon: GiWashingMachine,
    label: "Laundry",
  },
  {
    icon: FaDumbbell,
    label: "Gym",
  },
  {
    icon: FaSwimmer,
    label: "Pool",
  },
];

export default async function Page({
  params,
  searchParams,
}: {
  params: { id: string };
  searchParams: { [key: string]: string | string[] | undefined };
}) {
  const dormitory = await prisma.dormitory.findFirst({
    where: {
      id: params.id,
    },
    include: {
      owner: true,
      variants: true,
      managers: true,
      nearByColleges: true,
    },
  });
  return (
    <div>
      <MaxWidthWrapper>
        <div className="space-y-5">
          <ImageSlider images={dormitory?.images ?? [""]} />
          <div className="flex justify-between items-center">
            <div>
              <h1 className="text-xl font-semibold">{dormitory?.name}</h1>
              <p className="text-sm font-medium">0.7 km away</p>
              <div className="flex items-center gap-3">
                <div>
                  <Ratings rating={4.5} variant="yellow" size={18} />
                </div>
                <p className="font-bold">4.5</p>
                <Separator orientation="vertical" className="h-8" />
                <p className="text-sm font-medium text-muted-foreground">
                  120 Reviews
                </p>
              </div>
              <p className="text-lg font-bold mt-1">
                {formatPrice(120000)} - {formatPrice(150000)}
              </p>
            </div>
            <Button
              size={"icon"}
              variant={"outline"}
              className="text-primary rounded-full text-xl size-12 hover:text-primary active:text-primary"
            >
              <IoHeart />
            </Button>
          </div>
          <div className="space-y-2">
            <h3 className="text-primary font-medium text-lg">Description</h3>
            <p className="text-sm font-medium">{dormitory?.description}</p>
          </div>
          <div className="space-y-2">
            <h3 className="text-primary font-medium text-lg">Facilities</h3>
            <Carousel>
              <CarouselContent>
                {facilities.map((facility, index) => (
                  <CarouselItem className="basis-1/4" key={index}>
                    <div className="p-1">
                      <div className="flex items-center justify-center gap-1 flex-col bg-muted aspect-square rounded-lg">
                        <facility.icon className="text-xl" />
                        <p className="text-sm font-medium">{facility.label}</p>
                      </div>
                    </div>
                  </CarouselItem>
                ))}
              </CarouselContent>
            </Carousel>
          </div>

          <div className="fixed bottom-0 left-0 flex items-center justify-center z-20 w-full">
            <div className="w-full flex items-center">
              <MaxWidthWrapper className="border-t">
                {dormitory && (
                  <BookingComp data={dormitory} dormitory={dormitory} />
                )}
              </MaxWidthWrapper>
            </div>
          </div>
        </div>
      </MaxWidthWrapper>
    </div>
  );
}

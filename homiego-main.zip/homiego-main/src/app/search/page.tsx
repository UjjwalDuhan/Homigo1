import SearchComponent from "@/components/reusable/SearchComponent";
import MaxWidthWrapper from "@/components/wrappers/MaxWidthWrapper";
import React, { Suspense } from "react";
import FeaturedCard from "../(components)/FeaturedCard";
import SearchCard from "./(components)/SearchCard";
import { prisma, skipCondition } from "@/lib/prisma/prisma";
import { Skeleton } from "@/components/ui/skeleton";

const Listings = async ({
  params,
  searchParams,
}: {
  params: { slug: string };
  searchParams: { [key: string]: string | string[] | undefined };
}) => {
  const search = (searchParams.q as string) ?? "";
  const sortBy = (searchParams.sortBy as string) || "updatedAt";
  const sortOrder = (searchParams.sortOrder as "asc" | "desc") ?? "desc";
  const rpp_user = Number(process.env.RPP_USER ?? searchParams.rpp ?? 10);
  const page = parseInt((searchParams.page as string) ?? "1");

  const whereClause: any = {
    ...(search.length > 1 && {
      OR: [
        {
          name: { contains: search, mode: "insensitive" },
        },
      ],
    }),
  };
  const reservedParams = ["page", "q", "update", "sortBy", "sortOrder", "rpp"];
  Object.entries(searchParams).forEach(([key, value]) => {
    if (!reservedParams.includes(key)) {
      whereClause[key] = value;
    }
  });
  const dormitories = await prisma.dormitory.findMany({
    where: whereClause,
    orderBy: { [sortBy]: sortOrder },
    skip: skipCondition({ page, rpp: rpp_user }),
    take: rpp_user,
    include: {
      owner: true,
      variants: true,
      managers: true,
      nearByColleges: true,
    },
  });
  const totalUsers = await prisma.dormitory.count({
    where: whereClause,
  });
  const totalPages = Math.ceil(totalUsers / rpp_user);
  const filteredItems = dormitories.length;
  return (
    <>
      {dormitories.map((dormitory) => (
        <FeaturedCard key={dormitory.id} data={dormitory} dat={dormitory} />
      ))}
    </>
  );
};

const Loader = () => (
  <>
    <Skeleton className="w-full h-56 rounded-xl overflow-hidden" />
    <Skeleton className="w-full h-56 rounded-xl overflow-hidden" />
    <Skeleton className="w-full h-56 rounded-xl overflow-hidden" />
    <Skeleton className="w-full h-56 rounded-xl overflow-hidden" />
    <Skeleton className="w-full h-56 rounded-xl overflow-hidden" />
    <Skeleton className="w-full h-56 rounded-xl overflow-hidden" />
  </>
);

export default async function Page({
  params,
  searchParams,
}: {
  params: { slug: string };
  searchParams: { [key: string]: string | string[] | undefined };
}) {
  return (
    <div>
      <MaxWidthWrapper>
        <div className="space-y-6">
          <SearchComponent />
          <div className="space-y-4">
            <h2 className="text-xl font-semibold">Matched Properties</h2>
            <div className="gap-6 grid grid-cols-1">
              <Suspense key={`${searchParams.q}`} fallback={<Loader />}>
                <Listings params={params} searchParams={searchParams} />
              </Suspense>
            </div>
          </div>
        </div>
      </MaxWidthWrapper>
    </div>
  );
}

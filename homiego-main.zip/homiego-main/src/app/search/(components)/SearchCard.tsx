import React from "react";
import { Button } from "@/components/ui/button";
import Image from "next/image";
import { IoHeart, IoHeartOutline } from "react-icons/io5";
import { TbAirConditioning } from "react-icons/tb";
import { IoBedSharp } from "react-icons/io5";
import Link from "next/link";
import formatPrice from "@/lib/utils";

export default function SearchCard() {
  return (
    <div className="flex flex-col space-y-3 w-full">
      <Link
        href={"/dormitory/123"}
        className="relative w-full h-40 rounded-xl overflow-hidden"
      >
        <Image
          src={"/home_page_images/dummy_hostel.jpg"}
          alt={"Flat"}
          fill
          className="object-cover"
        />
        <Button
          size={"icon"}
          variant={"outline"}
          className="absolute top-2.5 right-2.5 rounded-full hover:text-primary active:text-primary"
        >
          <IoHeartOutline className="text-xl" />
        </Button>
        {/* <div className="absolute bottom-2.5 left-2.5 bg-opacity-30 backdrop-blur-lg text-white px-4 rounded-lg py-2 text-base font-medium">
          {formatPrice(120000)}
        </div> */}
      </Link>
      <div>
        <div className="flex justify-between items-center">
          <h1 className="text-lg font-semibold">Vivekanand Hostel</h1>
          <p className="text-base font-semibold">{formatPrice(120000)}</p>
        </div>
        <p className="text-sm font-medium text-gray-500">0.7 km away</p>
        <div className="flex items-center justify-between mt-1">
          <div className="flex items-center gap-2 text-sm font-medium">
            <TbAirConditioning className="text-xl" />
            <p>Air Conditioned</p>
          </div>
          <div className="flex items-center gap-2 text-sm font-medium">
            <IoBedSharp className="text-xl" />
            <p>3 Seater</p>
          </div>
        </div>
      </div>
    </div>
  );
}

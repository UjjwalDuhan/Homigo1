import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";
import {
  deleteFile,
  UploadcareSimpleAuthSchema,
} from "@uploadcare/rest-client";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

function formatPrice(amount: number): string {
  // Create a formatter object for the 'en-IN' locale (Indian English)
  const formatter = new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
    minimumFractionDigits: 0,
  });
  // Format the price using the formatter
  return formatter.format(amount);
}

export function getUserInitials(fullName: string): string {
  // Split the full name by spaces
  const nameParts = fullName.trim().split(/\s+/);

  // Extract the first letter of each part and convert to uppercase
  const initials = nameParts.map((part) => part[0].toUpperCase()).join("");

  return initials;
}

export const formatDate = (date: Date): string => {
  const day = date.getDate().toString().padStart(2, "0");
  const month = (date.getMonth() + 1).toString().padStart(2, "0"); // Months are zero-based
  const year = date.getFullYear().toString();
  return `${day}/${month}/${year}`;
};

export default formatPrice;
